﻿namespace Car_Gallery
{
    partial class AvailableCars
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AvailableCars));
            this.add_lbl = new System.Windows.Forms.Label();
            this.cars_grdv = new System.Windows.Forms.DataGridView();
            this.back_btn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.cars_grdv)).BeginInit();
            this.SuspendLayout();
            // 
            // add_lbl
            // 
            this.add_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.add_lbl.AutoSize = true;
            this.add_lbl.BackColor = System.Drawing.Color.Transparent;
            this.add_lbl.Font = new System.Drawing.Font("Impact", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_lbl.ForeColor = System.Drawing.Color.White;
            this.add_lbl.Location = new System.Drawing.Point(657, 11);
            this.add_lbl.Name = "add_lbl";
            this.add_lbl.Size = new System.Drawing.Size(665, 117);
            this.add_lbl.TabIndex = 23;
            this.add_lbl.Text = "*Available Cars*";
            this.add_lbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // cars_grdv
            // 
            this.cars_grdv.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cars_grdv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.cars_grdv.BackgroundColor = System.Drawing.Color.White;
            this.cars_grdv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cars_grdv.Location = new System.Drawing.Point(62, 378);
            this.cars_grdv.Name = "cars_grdv";
            this.cars_grdv.RowHeadersWidth = 62;
            this.cars_grdv.RowTemplate.Height = 28;
            this.cars_grdv.Size = new System.Drawing.Size(1820, 581);
            this.cars_grdv.TabIndex = 45;
            // 
            // back_btn
            // 
            this.back_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.back_btn.BackColor = System.Drawing.Color.White;
            this.back_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back_btn.Location = new System.Drawing.Point(43, 31);
            this.back_btn.Name = "back_btn";
            this.back_btn.Size = new System.Drawing.Size(153, 49);
            this.back_btn.TabIndex = 49;
            this.back_btn.Text = "Back";
            this.back_btn.UseVisualStyleBackColor = false;
            this.back_btn.Click += new System.EventHandler(this.back_btn_Click);
            // 
            // AvailableCars
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.back_btn);
            this.Controls.Add(this.cars_grdv);
            this.Controls.Add(this.add_lbl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AvailableCars";
            this.Text = "AvailableCars";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AvailableCars_FormClosing);
            this.Load += new System.EventHandler(this.AvailableCars_Load);
            ((System.ComponentModel.ISupportInitialize)(this.cars_grdv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label add_lbl;
        private System.Windows.Forms.DataGridView cars_grdv;
        private System.Windows.Forms.Button back_btn;
    }
}