﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;

namespace Car_Gallery
{
    internal class Rental
    {
        public string ConnectionString = "Data Source=(DESCRIPTION=" +
              "(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))" +
              "(CONNECT_DATA=(SERVICE_NAME=XE)));" +
              "User Id=CAR GALLERY;Password=456;";
        public Rental()
        {
           
        }
        public void InsertDataIntoOracle(RentalsData R)
        {
            string today = DateTime.Today.ToString("dd-MMM-yyyy");
            string futureDate = DateTime.Today.AddDays(3).ToString("dd-MMM-yyyy");
            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionString))
                {
                    connection.Open();

                    string query = "insert into Rentals(CustomerID,CarID,RentalDate,ReturnDate,RentalStatus) values(:cusid,:cid,TO_DATE(:rd1, 'DD-Mon-YYYY') ,TO_DATE(:rd, 'DD-Mon-YYYY'),'Rented')";
                    OracleCommand cmd = new OracleCommand(query, connection);
                    cmd.Parameters.Add(new OracleParameter("cusid", R.GetCustomer()));
                    cmd.Parameters.Add(new OracleParameter("cid", R.GetCarId()));
                    cmd.Parameters.Add(new OracleParameter("rd1", today));
                    cmd.Parameters.Add(new OracleParameter("rd", futureDate));
                    cmd.ExecuteNonQuery();
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
       
        public void ChangeAvailablityStatus(RentalsData R)
        {
            string today = DateTime.Today.ToString("dd-MMM-yyyy");
            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionString))
                {
                    connection.Open();

                    string query = "Update  Rentals Set RENTALSTATUS='Available',ReturnDate=:rd1 Where CarID=:carid And CustomerID=:cusid";
                    OracleCommand cmd = new OracleCommand(query, connection);
                    cmd.Parameters.Add(new OracleParameter("carid", R.GetCarId()));
                    cmd.Parameters.Add(new OracleParameter("cusid", R.GetCustomer()));
                    cmd.Parameters.Add(new OracleParameter("rd1", today));
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public DataTable RentalHistory(int cusid)
        {
            try
            {
                string query = "SELECT *FROM RENTALS WHERE CustomerID="+cusid+"";
                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    OracleDataAdapter adapter = new OracleDataAdapter(query, conn);
                    DataTable table = new DataTable();

                    adapter.Fill(table);
                    return table;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                DataTable table = new DataTable();
                return table;

            }
        }
    }
}
