﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Gallery
{
    internal class CarsData
    {
        int CarId;
        string Name;
        string NumberPlate;
        string Color;
        int RentalPrice;
        string Model;
        public CarsData() { }
        public CarsData( string name, string numberPlate, string color, int rentalPrice, string model)
        {
            CarId = 0;
            Name = name;
            NumberPlate = numberPlate;
            Color = color;
            RentalPrice = rentalPrice;
            Model = model;
        }
        public void SetCarId(int carId) {CarId = carId; }
        public int GetCarId() { return CarId; }
        public void SetName(string name) {Name = name;}
        public string GetName() { return Name;}
        public void SetNumberPalte(string numberPalte) { NumberPlate = numberPalte; }
        public string GetNumberPalte() { return NumberPlate;}
        public void SetColor(string color) { Color = color;}
        public string GetColor() { return Color;}
        public void SetRentalPrize(int rentalPrize) {
            RentalPrice = rentalPrize;
        }
        public int GetRentalPrize( ) { return RentalPrice; }
        public void SetModel(string model) { Model = model;}
        public string GetModel() { return Model;}   
    }
}
