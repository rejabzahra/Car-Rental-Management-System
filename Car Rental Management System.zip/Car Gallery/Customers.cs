﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using Oracle.ManagedDataAccess.Client;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;


namespace Car_Gallery
{
    internal class Customers
    {
        public string ConnectionString = "Data Source=(DESCRIPTION=" +
              "(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))" +
              "(CONNECT_DATA=(SERVICE_NAME=XE)));" +
              "User Id=CAR GALLERY;Password=456;";

        
        public Customers() 
        {
            
        }
        
        public int InsertDataIntoOracle(CustomerData C)
        {
            int id = 0;

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionString))
                {
                    connection.Open();

                    string query = "Insert into Customer (Username,Password,FullName,Email,Phone) values(:username,:password,:fullName,:email,:phone)";
                    OracleCommand cmd = new OracleCommand(query, connection);
                    cmd.Parameters.Add(new OracleParameter("username", C.GetUsername()));
                    cmd.Parameters.Add(new OracleParameter("password", C.GetPassword()));
                    cmd.Parameters.Add(new OracleParameter("fullName", C.GetFullName()));
                    cmd.Parameters.Add(new OracleParameter("email", C.GetEmail()));
                    cmd.Parameters.Add(new OracleParameter("phone", C.GetPhone()));

                    cmd.ExecuteNonQuery();
                    string query1 = "Select CustomerID From Customer Where UserName =:username";
                    cmd = new OracleCommand(query1, connection);
                    cmd.Parameters.Add(new OracleParameter("username", C.GetUsername()));
                    id = Convert.ToInt32(cmd.ExecuteScalar());
                    return id;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return id;
            }
        }
        public void UpdateDataFromLists(CustomerData C)
        {
            try
            {
                string query = "Update Customer Set UserName=:uname,Password=:pass,FullName=:fname,Email=:email,Phone=:phone where CustomerID=:customerid";
                using (OracleConnection con = new OracleConnection(ConnectionString))
                {
                    con.Open();
                    OracleCommand cmd = new OracleCommand(query, con);
                    cmd.Parameters.Add(new OracleParameter("uname", C.GetUsername()));
                    cmd.Parameters.Add(new OracleParameter("pass", C.GetPassword()));
                    cmd.Parameters.Add(new OracleParameter("fname", C.GetFullName()));
                    cmd.Parameters.Add(new OracleParameter("email", C.GetEmail()));
                    cmd.Parameters.Add(new OracleParameter("phone", C.GetPhone()));
                    cmd.Parameters.Add(new OracleParameter("customerid", C.GetCustomerId()));  

                    cmd.ExecuteNonQuery();


                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        public CustomerData SearchOInBasisOfUsernamePassword(string username, string password)
        {
            CustomerData A = new CustomerData();
            try
            {
                string query = "SELECT * FROM Customer Where UserName='" + username + "' AND Password ='" + password + "'";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    conn.Open();
                    OracleDataAdapter adapter = new OracleDataAdapter(query, conn);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    foreach (DataRow row in table.Rows)
                    {
                        A.SetCustomerId(Convert.ToInt32(row["CustomerID"]));
                        A.SetUsername(row["Username"].ToString());
                        A.SetPassword(row["Password"].ToString());
                        A.SetFullName(row["FullName"].ToString());
                        A.SetEmail(row["Email"].ToString());
                        A.SetPhone(row["Phone"].ToString());
                    }
                }
                return A;


            }
            catch (Exception ex)
            {
                MessageBox.Show("Error112: " + ex.Message);
                return A;

            }

        }
       
        public CustomerData MyData(int id)
        {
            CustomerData A = new CustomerData();
            try
            {
                string query = "SELECT * FROM Customer Where CustomerID = " + id + "";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    conn.Open();
                    OracleDataAdapter adapter = new OracleDataAdapter(query, conn);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    foreach (DataRow row in table.Rows)
                    {
                        A.SetCustomerId(Convert.ToInt32(row["CustomerID"]));
                        A.SetUsername(row["Username"].ToString());
                        A.SetPassword(row["Password"].ToString());
                        A.SetFullName(row["FullName"].ToString());
                        A.SetEmail(row["Email"].ToString());
                        A.SetPhone(row["Phone"].ToString());
                    }
                }
                return A;


            }
            catch (Exception ex)
            {
                MessageBox.Show("Error112: " + ex.Message);
                return A;

            }
        }
    }
}
