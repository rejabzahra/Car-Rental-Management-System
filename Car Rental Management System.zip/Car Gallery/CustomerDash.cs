﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Gallery
{
    public partial class CustomerDash : Form
    {
        int ID;
        public CustomerDash(int id)
        {
            InitializeComponent();
            ID = id;
        }

        private void CustomerDash_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void CustomerDash_Load(object sender, EventArgs e)
        {

        }

        private void logout_btn_Click(object sender, EventArgs e)
        {
            CustomerLogIn customer=new CustomerLogIn();
            this.Hide();
            customer.Show();
        }

        private void rent_btn_Click(object sender, EventArgs e)
        {
            RentCar rent=new RentCar( ID);
            this.Hide();
            rent.Show();
        }

        private void return_btn_Click(object sender, EventArgs e)
        {
            ReturnCar returnCar = new ReturnCar( ID);
            this.Hide();
            returnCar.Show();
        }

        private void upd_btn_Click(object sender, EventArgs e)
        {
            UpdateCustm updateCustm = new UpdateCustm( ID);
            this.Hide();
            updateCustm.Show();
        }

        private void avail_btn_Click(object sender, EventArgs e)
        {
            AvailCarCustm availCarCustm = new AvailCarCustm( ID);
            this.Hide();
            availCarCustm.Show();
        }

        private void history_btn_Click(object sender, EventArgs e)
        {
            RentingHistory history = new RentingHistory(ID);
            this.Hide();
            history.Show();
        }
    }
}
