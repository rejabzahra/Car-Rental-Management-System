﻿namespace Car_Gallery
{
    partial class SearchCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SearchCar));
            this.search_lbl = new System.Windows.Forms.Label();
            this.rentalprice_lbl = new System.Windows.Forms.Label();
            this.name_lbl = new System.Windows.Forms.Label();
            this.color_lbl = new System.Windows.Forms.Label();
            this.price_cmbo = new System.Windows.Forms.ComboBox();
            this.color_cmbo = new System.Windows.Forms.ComboBox();
            this.name_cmbo = new System.Windows.Forms.ComboBox();
            this.cars_grdv = new System.Windows.Forms.DataGridView();
            this.back_btn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.cars_grdv)).BeginInit();
            this.SuspendLayout();
            // 
            // search_lbl
            // 
            this.search_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.search_lbl.AutoSize = true;
            this.search_lbl.BackColor = System.Drawing.Color.Transparent;
            this.search_lbl.Font = new System.Drawing.Font("Impact", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search_lbl.ForeColor = System.Drawing.Color.White;
            this.search_lbl.Location = new System.Drawing.Point(771, 52);
            this.search_lbl.Name = "search_lbl";
            this.search_lbl.Size = new System.Drawing.Size(534, 117);
            this.search_lbl.TabIndex = 23;
            this.search_lbl.Text = "*Search Car*";
            this.search_lbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // rentalprice_lbl
            // 
            this.rentalprice_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rentalprice_lbl.AutoSize = true;
            this.rentalprice_lbl.BackColor = System.Drawing.Color.Transparent;
            this.rentalprice_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rentalprice_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.rentalprice_lbl.Location = new System.Drawing.Point(112, 361);
            this.rentalprice_lbl.Name = "rentalprice_lbl";
            this.rentalprice_lbl.Size = new System.Drawing.Size(204, 36);
            this.rentalprice_lbl.TabIndex = 36;
            this.rentalprice_lbl.Text = "Rental Price :";
            this.rentalprice_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // name_lbl
            // 
            this.name_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.name_lbl.AutoSize = true;
            this.name_lbl.BackColor = System.Drawing.Color.Transparent;
            this.name_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.name_lbl.Location = new System.Drawing.Point(591, 233);
            this.name_lbl.Name = "name_lbl";
            this.name_lbl.Size = new System.Drawing.Size(114, 36);
            this.name_lbl.TabIndex = 35;
            this.name_lbl.Text = "Name :";
            this.name_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // color_lbl
            // 
            this.color_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.color_lbl.AutoSize = true;
            this.color_lbl.BackColor = System.Drawing.Color.Transparent;
            this.color_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.color_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.color_lbl.Location = new System.Drawing.Point(1135, 361);
            this.color_lbl.Name = "color_lbl";
            this.color_lbl.Size = new System.Drawing.Size(111, 36);
            this.color_lbl.TabIndex = 33;
            this.color_lbl.Text = "Color :";
            this.color_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // price_cmbo
            // 
            this.price_cmbo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.price_cmbo.FormattingEnabled = true;
            this.price_cmbo.Location = new System.Drawing.Point(359, 371);
            this.price_cmbo.Name = "price_cmbo";
            this.price_cmbo.Size = new System.Drawing.Size(337, 28);
            this.price_cmbo.TabIndex = 39;
            this.price_cmbo.SelectedIndexChanged += new System.EventHandler(this.price_cmbo_SelectedIndexChanged);
            // 
            // color_cmbo
            // 
            this.color_cmbo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.color_cmbo.FormattingEnabled = true;
            this.color_cmbo.Location = new System.Drawing.Point(1318, 371);
            this.color_cmbo.Name = "color_cmbo";
            this.color_cmbo.Size = new System.Drawing.Size(337, 28);
            this.color_cmbo.TabIndex = 40;
            this.color_cmbo.SelectedIndexChanged += new System.EventHandler(this.color_cmbo_SelectedIndexChanged);
            // 
            // name_cmbo
            // 
            this.name_cmbo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.name_cmbo.FormattingEnabled = true;
            this.name_cmbo.Location = new System.Drawing.Point(840, 257);
            this.name_cmbo.Name = "name_cmbo";
            this.name_cmbo.Size = new System.Drawing.Size(337, 28);
            this.name_cmbo.TabIndex = 42;
            this.name_cmbo.SelectedIndexChanged += new System.EventHandler(this.name_cmbo_SelectedIndexChanged);
            // 
            // cars_grdv
            // 
            this.cars_grdv.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cars_grdv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.cars_grdv.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.cars_grdv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cars_grdv.Location = new System.Drawing.Point(50, 470);
            this.cars_grdv.Name = "cars_grdv";
            this.cars_grdv.RowHeadersWidth = 62;
            this.cars_grdv.RowTemplate.Height = 28;
            this.cars_grdv.Size = new System.Drawing.Size(1823, 531);
            this.cars_grdv.TabIndex = 44;
            // 
            // back_btn
            // 
            this.back_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.back_btn.BackColor = System.Drawing.Color.White;
            this.back_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back_btn.Location = new System.Drawing.Point(93, 70);
            this.back_btn.Name = "back_btn";
            this.back_btn.Size = new System.Drawing.Size(236, 70);
            this.back_btn.TabIndex = 49;
            this.back_btn.Text = "Back";
            this.back_btn.UseVisualStyleBackColor = false;
            this.back_btn.Click += new System.EventHandler(this.back_btn_Click);
            // 
            // SearchCar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.back_btn);
            this.Controls.Add(this.cars_grdv);
            this.Controls.Add(this.name_cmbo);
            this.Controls.Add(this.color_cmbo);
            this.Controls.Add(this.price_cmbo);
            this.Controls.Add(this.rentalprice_lbl);
            this.Controls.Add(this.name_lbl);
            this.Controls.Add(this.color_lbl);
            this.Controls.Add(this.search_lbl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SearchCar";
            this.Text = "SearchCar";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SearchCar_FormClosing);
            this.Load += new System.EventHandler(this.SearchCar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.cars_grdv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label search_lbl;
        private System.Windows.Forms.Label rentalprice_lbl;
        private System.Windows.Forms.Label name_lbl;
        private System.Windows.Forms.Label color_lbl;
        private System.Windows.Forms.ComboBox price_cmbo;
        private System.Windows.Forms.ComboBox color_cmbo;
        private System.Windows.Forms.ComboBox name_cmbo;
        private System.Windows.Forms.DataGridView cars_grdv;
        private System.Windows.Forms.Button back_btn;
    }
}