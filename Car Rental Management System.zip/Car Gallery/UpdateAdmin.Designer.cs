﻿namespace Car_Gallery
{
    partial class UpdateAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdateAdmin));
            this.upload_btn = new System.Windows.Forms.Button();
            this.pic_lbl = new System.Windows.Forms.Label();
            this.pic_Box = new System.Windows.Forms.PictureBox();
            this.mail_lbl = new System.Windows.Forms.Label();
            this.mail_box = new System.Windows.Forms.TextBox();
            this.no_box = new System.Windows.Forms.TextBox();
            this.pass_box = new System.Windows.Forms.TextBox();
            this.user_box = new System.Windows.Forms.TextBox();
            this.no_lbl = new System.Windows.Forms.Label();
            this.pass_lbl = new System.Windows.Forms.Label();
            this.useer_lbl = new System.Windows.Forms.Label();
            this.update_btn = new System.Windows.Forms.Button();
            this.name_lbl = new System.Windows.Forms.Label();
            this.update_lbl = new System.Windows.Forms.Label();
            this.name_box = new System.Windows.Forms.TextBox();
            this.back_btn = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Box)).BeginInit();
            this.SuspendLayout();
            // 
            // upload_btn
            // 
            this.upload_btn.BackColor = System.Drawing.Color.White;
            this.upload_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.upload_btn.Location = new System.Drawing.Point(1236, 662);
            this.upload_btn.Name = "upload_btn";
            this.upload_btn.Size = new System.Drawing.Size(277, 72);
            this.upload_btn.TabIndex = 47;
            this.upload_btn.Text = "Update Picture";
            this.upload_btn.UseVisualStyleBackColor = false;
            this.upload_btn.Click += new System.EventHandler(this.upload_btn_Click);
            // 
            // pic_lbl
            // 
            this.pic_lbl.AutoSize = true;
            this.pic_lbl.BackColor = System.Drawing.Color.Transparent;
            this.pic_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pic_lbl.ForeColor = System.Drawing.Color.White;
            this.pic_lbl.Location = new System.Drawing.Point(1299, 235);
            this.pic_lbl.Name = "pic_lbl";
            this.pic_lbl.Size = new System.Drawing.Size(146, 36);
            this.pic_lbl.TabIndex = 46;
            this.pic_lbl.Text = "*Picture*";
            // 
            // pic_Box
            // 
            this.pic_Box.BackColor = System.Drawing.Color.Transparent;
            this.pic_Box.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_Box.Location = new System.Drawing.Point(1236, 318);
            this.pic_Box.Name = "pic_Box";
            this.pic_Box.Size = new System.Drawing.Size(277, 259);
            this.pic_Box.TabIndex = 45;
            this.pic_Box.TabStop = false;
            // 
            // mail_lbl
            // 
            this.mail_lbl.AutoSize = true;
            this.mail_lbl.BackColor = System.Drawing.Color.Transparent;
            this.mail_lbl.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mail_lbl.ForeColor = System.Drawing.Color.White;
            this.mail_lbl.Location = new System.Drawing.Point(464, 583);
            this.mail_lbl.Name = "mail_lbl";
            this.mail_lbl.Size = new System.Drawing.Size(161, 32);
            this.mail_lbl.TabIndex = 44;
            this.mail_lbl.Text = "Enter email:";
            // 
            // mail_box
            // 
            this.mail_box.Location = new System.Drawing.Point(732, 589);
            this.mail_box.Name = "mail_box";
            this.mail_box.Size = new System.Drawing.Size(290, 26);
            this.mail_box.TabIndex = 43;
            this.mail_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // no_box
            // 
            this.no_box.Location = new System.Drawing.Point(732, 708);
            this.no_box.Name = "no_box";
            this.no_box.Size = new System.Drawing.Size(290, 26);
            this.no_box.TabIndex = 42;
            this.no_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pass_box
            // 
            this.pass_box.Location = new System.Drawing.Point(732, 349);
            this.pass_box.Name = "pass_box";
            this.pass_box.Size = new System.Drawing.Size(290, 26);
            this.pass_box.TabIndex = 41;
            this.pass_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // user_box
            // 
            this.user_box.Location = new System.Drawing.Point(732, 241);
            this.user_box.Name = "user_box";
            this.user_box.Size = new System.Drawing.Size(290, 26);
            this.user_box.TabIndex = 40;
            this.user_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // no_lbl
            // 
            this.no_lbl.AutoSize = true;
            this.no_lbl.BackColor = System.Drawing.Color.Transparent;
            this.no_lbl.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.no_lbl.ForeColor = System.Drawing.Color.Transparent;
            this.no_lbl.Location = new System.Drawing.Point(464, 702);
            this.no_lbl.Name = "no_lbl";
            this.no_lbl.Size = new System.Drawing.Size(214, 32);
            this.no_lbl.TabIndex = 39;
            this.no_lbl.Text = "Enter Phone No:";
            // 
            // pass_lbl
            // 
            this.pass_lbl.AutoSize = true;
            this.pass_lbl.BackColor = System.Drawing.Color.Transparent;
            this.pass_lbl.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pass_lbl.ForeColor = System.Drawing.Color.White;
            this.pass_lbl.Location = new System.Drawing.Point(464, 343);
            this.pass_lbl.Name = "pass_lbl";
            this.pass_lbl.Size = new System.Drawing.Size(212, 32);
            this.pass_lbl.TabIndex = 38;
            this.pass_lbl.Text = "Enter Password:";
            // 
            // useer_lbl
            // 
            this.useer_lbl.AutoSize = true;
            this.useer_lbl.BackColor = System.Drawing.Color.Transparent;
            this.useer_lbl.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.useer_lbl.ForeColor = System.Drawing.Color.White;
            this.useer_lbl.Location = new System.Drawing.Point(464, 235);
            this.useer_lbl.Name = "useer_lbl";
            this.useer_lbl.Size = new System.Drawing.Size(220, 32);
            this.useer_lbl.TabIndex = 37;
            this.useer_lbl.Text = "Enter UserName:";
            // 
            // update_btn
            // 
            this.update_btn.BackColor = System.Drawing.Color.White;
            this.update_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.update_btn.Location = new System.Drawing.Point(601, 795);
            this.update_btn.Name = "update_btn";
            this.update_btn.Size = new System.Drawing.Size(236, 70);
            this.update_btn.TabIndex = 36;
            this.update_btn.Text = "Update";
            this.update_btn.UseVisualStyleBackColor = false;
            this.update_btn.Click += new System.EventHandler(this.update_btn_Click);
            // 
            // name_lbl
            // 
            this.name_lbl.AutoSize = true;
            this.name_lbl.BackColor = System.Drawing.Color.Transparent;
            this.name_lbl.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name_lbl.ForeColor = System.Drawing.Color.White;
            this.name_lbl.Location = new System.Drawing.Point(464, 463);
            this.name_lbl.Name = "name_lbl";
            this.name_lbl.Size = new System.Drawing.Size(222, 32);
            this.name_lbl.TabIndex = 35;
            this.name_lbl.Text = "Enter Full Name:";
            // 
            // update_lbl
            // 
            this.update_lbl.AutoSize = true;
            this.update_lbl.BackColor = System.Drawing.Color.Transparent;
            this.update_lbl.Font = new System.Drawing.Font("Impact", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.update_lbl.ForeColor = System.Drawing.Color.White;
            this.update_lbl.Location = new System.Drawing.Point(514, 44);
            this.update_lbl.Name = "update_lbl";
            this.update_lbl.Size = new System.Drawing.Size(660, 117);
            this.update_lbl.TabIndex = 34;
            this.update_lbl.Text = "*Update Profile*";
            this.update_lbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // name_box
            // 
            this.name_box.Location = new System.Drawing.Point(732, 469);
            this.name_box.Name = "name_box";
            this.name_box.Size = new System.Drawing.Size(290, 26);
            this.name_box.TabIndex = 33;
            this.name_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // back_btn
            // 
            this.back_btn.BackColor = System.Drawing.Color.White;
            this.back_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back_btn.Location = new System.Drawing.Point(80, 91);
            this.back_btn.Name = "back_btn";
            this.back_btn.Size = new System.Drawing.Size(236, 70);
            this.back_btn.TabIndex = 48;
            this.back_btn.Text = "Back";
            this.back_btn.UseVisualStyleBackColor = false;
            this.back_btn.Click += new System.EventHandler(this.back_btn_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // UpdateAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1713, 1050);
            this.Controls.Add(this.back_btn);
            this.Controls.Add(this.upload_btn);
            this.Controls.Add(this.pic_lbl);
            this.Controls.Add(this.pic_Box);
            this.Controls.Add(this.mail_lbl);
            this.Controls.Add(this.mail_box);
            this.Controls.Add(this.no_box);
            this.Controls.Add(this.pass_box);
            this.Controls.Add(this.user_box);
            this.Controls.Add(this.no_lbl);
            this.Controls.Add(this.pass_lbl);
            this.Controls.Add(this.useer_lbl);
            this.Controls.Add(this.update_btn);
            this.Controls.Add(this.name_lbl);
            this.Controls.Add(this.update_lbl);
            this.Controls.Add(this.name_box);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "UpdateAdmin";
            this.Text = "UpdateAdmin";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.UpdateAdmin_FormClosing);
            this.Load += new System.EventHandler(this.UpdateAdmin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pic_Box)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button upload_btn;
        private System.Windows.Forms.Label pic_lbl;
        private System.Windows.Forms.PictureBox pic_Box;
        private System.Windows.Forms.Label mail_lbl;
        private System.Windows.Forms.TextBox mail_box;
        private System.Windows.Forms.TextBox no_box;
        private System.Windows.Forms.TextBox pass_box;
        private System.Windows.Forms.TextBox user_box;
        private System.Windows.Forms.Label no_lbl;
        private System.Windows.Forms.Label pass_lbl;
        private System.Windows.Forms.Label useer_lbl;
        private System.Windows.Forms.Button update_btn;
        private System.Windows.Forms.Label name_lbl;
        private System.Windows.Forms.Label update_lbl;
        private System.Windows.Forms.TextBox name_box;
        private System.Windows.Forms.Button back_btn;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}