﻿namespace Car_Gallery
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            this.dash_lbl = new System.Windows.Forms.Label();
            this.user_lbl = new System.Windows.Forms.Label();
            this.admin_btn = new System.Windows.Forms.Button();
            this.custm_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // dash_lbl
            // 
            this.dash_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dash_lbl.AutoSize = true;
            this.dash_lbl.BackColor = System.Drawing.Color.Transparent;
            this.dash_lbl.Font = new System.Drawing.Font("Impact", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dash_lbl.Location = new System.Drawing.Point(97, 71);
            this.dash_lbl.Name = "dash_lbl";
            this.dash_lbl.Size = new System.Drawing.Size(798, 176);
            this.dash_lbl.TabIndex = 0;
            this.dash_lbl.Text = "CAR GALLERY";
            this.dash_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // user_lbl
            // 
            this.user_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.user_lbl.AutoSize = true;
            this.user_lbl.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.user_lbl.Font = new System.Drawing.Font("Microsoft YaHei", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_lbl.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.user_lbl.Location = new System.Drawing.Point(232, 302);
            this.user_lbl.Name = "user_lbl";
            this.user_lbl.Size = new System.Drawing.Size(516, 75);
            this.user_lbl.TabIndex = 1;
            this.user_lbl.Text = "Select User Type:";
            this.user_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.user_lbl.Click += new System.EventHandler(this.user_lbl_Click);
            // 
            // admin_btn
            // 
            this.admin_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.admin_btn.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.admin_btn.Font = new System.Drawing.Font("Microsoft PhagsPa", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.admin_btn.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.admin_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.admin_btn.Location = new System.Drawing.Point(166, 449);
            this.admin_btn.Name = "admin_btn";
            this.admin_btn.Size = new System.Drawing.Size(283, 82);
            this.admin_btn.TabIndex = 2;
            this.admin_btn.Text = "ADMIN";
            this.admin_btn.UseVisualStyleBackColor = false;
            this.admin_btn.Click += new System.EventHandler(this.admin_btn_Click);
            // 
            // custm_btn
            // 
            this.custm_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.custm_btn.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.custm_btn.Font = new System.Drawing.Font("Microsoft PhagsPa", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.custm_btn.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.custm_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.custm_btn.Location = new System.Drawing.Point(592, 449);
            this.custm_btn.Name = "custm_btn";
            this.custm_btn.Size = new System.Drawing.Size(295, 82);
            this.custm_btn.TabIndex = 3;
            this.custm_btn.Text = "CUSTOMER";
            this.custm_btn.UseVisualStyleBackColor = false;
            this.custm_btn.Click += new System.EventHandler(this.custm_btn_Click);
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(958, 663);
            this.Controls.Add(this.custm_btn);
            this.Controls.Add(this.admin_btn);
            this.Controls.Add(this.user_lbl);
            this.Controls.Add(this.dash_lbl);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Dashboard";
            this.Text = "Dashboard";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Dashboard_FormClosing);
            this.Load += new System.EventHandler(this.Dashboard_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label dash_lbl;
        private System.Windows.Forms.Label user_lbl;
        private System.Windows.Forms.Button admin_btn;
        private System.Windows.Forms.Button custm_btn;
    }
}