﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Gallery
{
    public partial class Cars : Form
    {
        public Cars()
        {
            InitializeComponent();
        }
        private async void Cars_Load(object sender, EventArgs e)//event
        //async will do some tasks that might take time but won't freeze the form
        {
            await StartLoading();//does pausing without freezing(Non-blocking delay)
        }
        private async Task StartLoading()//method
        //task is a return type that doesn't return anything but still runs a method 
        {
            progressBar.Value = 0;
            for (int i = 0; i <= 100; i++)
            {
                progressBar.Value = i;
                await Task.Delay(18); // (better than Thread.Sleep)
            }
            await Task.Delay(500);
            Dashboard db = new Dashboard();
            this.Hide();
            db.Show();
            
            
        }
        private void progressBar_Click(object sender, EventArgs e)
        {

        }

        private void Cars_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
