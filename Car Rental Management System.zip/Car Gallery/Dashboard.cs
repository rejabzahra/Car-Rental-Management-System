﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;
using System.Xml.Linq;

namespace Car_Gallery
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
           
        }
        private void admin_btn_Click(object sender, EventArgs e)
        {
            AdminLogin login = new AdminLogin();
            this.Hide();
            login.Show();
        }
        private void Dashboard_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
        private void custm_btn_Click(object sender, EventArgs e)
        {
            CustomerLogIn customer = new CustomerLogIn();
            this.Hide();
            customer.Show();
        }
        private void Dashboard_Load(object sender, EventArgs e)
        {

        }
        private void user_lbl_Click(object sender, EventArgs e)
        {

        }
    }
}
