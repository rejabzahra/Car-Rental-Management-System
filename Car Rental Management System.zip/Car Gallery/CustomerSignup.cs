﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OracleClient;
using System.IO;

namespace Car_Gallery
{
    public partial class CustomerSignup : Form
    {
        public string ConnectionString = "Data Source=(DESCRIPTION=" +
              "(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))" +
              "(CONNECT_DATA=(SERVICE_NAME=XE)));" +
              "User Id=CAR GALLERY;Password=456;";
        int Id;
        byte[] img;
        public CustomerSignup()
        {
            InitializeComponent();
        }

        private void CustomerSignup_Load(object sender, EventArgs e)
        {

        }

        private void CustomerSignup_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void sign_btn_Click(object sender, EventArgs e)
        {
           if(user_box.Text!=""&& pass_box.Text != ""&& name_box.Text != ""&& mail_box.Text != ""&& no_box.Text != "" && pic_Box.Image!=null)
           {
                Customers C=new Customers();
                CustomerData c=new CustomerData(user_box.Text.ToString(), pass_box.Text.ToString(), name_box.Text.ToString(), mail_box.Text.ToString(), no_box.Text.ToString());
                int id = C.InsertDataIntoOracle(c);
                Id = id;
                try
                {
                    OracleConnection con = new OracleConnection(ConnectionString);
                    con.Open();
                    String query = "Insert into CustomerPictures (CustomerID,Picture) values(:ID,:imag)";

                    OracleParameter picparameter = new OracleParameter();


                    picparameter.OracleType = OracleType.Blob;

                    picparameter.ParameterName = "imag";

                    picparameter.Value = img.ToArray();

                    OracleCommand cmd = new OracleCommand(query, con);
                    cmd.Parameters.Add(picparameter);
                    cmd.Parameters.Add(new OracleParameter("ID", Id));

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Image Save Successfully!!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    MessageBox.Show("Welcome to our site");
                    CustomerDash customerDash = new CustomerDash(Id);
                    this.Hide();
                    customerDash.Show();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
           }
            else
            {
                MessageBox.Show("Enter Alll Your Asked Information First!");
            }
        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            CustomerLogIn custom= new CustomerLogIn();
            this.Hide();
            custom.Show();
        }

        private void pass_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void upload_btn_Click(object sender, EventArgs e)
        {
            try
            {
                OracleConnection con = new OracleConnection(ConnectionString);


                openFileDialog1.InitialDirectory = @"C:\";
                openFileDialog1.Filter = "[JPG,JPEG]|*.jpg; *.png";
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    FileStream FS = new FileStream(@openFileDialog1.FileName, FileMode.Open, FileAccess.Read);
                    img = new byte[FS.Length];
                    FS.Read(img, 0, Convert.ToInt32(FS.Length));
                    pic_Box.Image = Image.FromFile(openFileDialog1.FileName);
                    pic_Box.SizeMode = PictureBoxSizeMode.StretchImage;


                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
