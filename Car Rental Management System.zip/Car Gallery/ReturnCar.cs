﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Gallery
{
    public partial class ReturnCar : Form
    {
        int ID;
        public ReturnCar(int id)
        {
            InitializeComponent();
            ID = id;
        }

        private void ReturnCar_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            CustomerDash customerDash = new CustomerDash(ID);
            this.Hide();
            customerDash.Show();
        }

        private void ReturnCar_Load(object sender, EventArgs e)
        {
            List<int> carsid = new List<int>();
            Car cars=new Car();
            carsid = cars.RentedCarsID(ID);
            for (int i = 0; i < carsid.Count; i++)
            {
                id_cmbo.Items.Add(carsid[i]);
            }
        }

        private void id_cmbo_SelectedIndexChanged(object sender, EventArgs e)
        {
            Car cars = new Car();
            name_box.Text = cars.NAME(Convert.ToInt32(id_cmbo.SelectedItem));
            noplate_box.Text = cars.NUMBERPLATE(Convert.ToInt32(id_cmbo.SelectedItem));
            color_box.Text = cars.COLOR(Convert.ToInt32(id_cmbo.SelectedItem));
            rentalprice_box.Text = cars.RENTALPRICE(Convert.ToInt32(id_cmbo.SelectedItem)).ToString();
            model_box.Text = cars.MODEL(Convert.ToInt32(id_cmbo.SelectedItem));
        }

        private void return_btn_Click(object sender, EventArgs e)
        {
            if (id_cmbo.SelectedIndex != -1)
            {
                RentalsData data = new RentalsData(ID, Convert.ToInt32(id_cmbo.SelectedItem));
                Rental rental = new Rental();
                rental.ChangeAvailablityStatus(data);
                MessageBox.Show("Car Returned successfully");
                ReturnCar car = new ReturnCar(ID);
                this.Hide();
                car.Show();

            }
            else
            {
                MessageBox.Show("Select Item in ComboBox");

            }
        }
    }
}
