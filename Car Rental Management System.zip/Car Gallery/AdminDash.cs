﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Gallery
{
    public partial class AdminDash : Form
    {
        int ID;
        public AdminDash( int id)
        {
            InitializeComponent();
            ID = id;
        }

        private void AdminDash_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void AdminDash_Load(object sender, EventArgs e)
        {

        }

        private void admin_lbl_Click(object sender, EventArgs e)
        {

        }

        private void logout_btn_Click(object sender, EventArgs e)
        {
            AdminLogin login = new AdminLogin();
            this.Hide();
            login.Show();
        }

        private void add_btn_Click(object sender, EventArgs e)
        {
            AddCar add=new AddCar(ID);
            this.Hide();
            add.Show();
        }

        private void search_btn_Click(object sender, EventArgs e)
        {
            SearchCar search=new SearchCar(ID);
            this.Hide();
            search.Show();
        }

        private void view_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            ViewCars viewCars = new ViewCars(ID);
            viewCars.Show();
        }

        private void rem_btn_Click(object sender, EventArgs e)
        {
            Rem_Upd_Car rem_Upd_Car = new Rem_Upd_Car(ID);
            this.Hide();
            rem_Upd_Car.Show();
        }

        private void uvail_btn_Click(object sender, EventArgs e)
        {
            AvailableCars availableCars = new AvailableCars(ID);
            this.Hide();
            availableCars.Show();
        }

        private void rented_btn_Click(object sender, EventArgs e)
        {
            RentedCars rentedCars = new RentedCars(ID);
            this.Hide();
            rentedCars.Show();
        }

        private void upd_btn_Click(object sender, EventArgs e)
        {
            UpdateAdmin updateAdmin = new UpdateAdmin(ID);
            this.Hide();
            updateAdmin.Show();
        }
    }
}
