﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OracleClient;
using System.IO;

namespace Car_Gallery
{
    public partial class UpdateCustm : Form
    {
        public string ConnectionString = "Data Source=(DESCRIPTION=" +
              "(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))" +
              "(CONNECT_DATA=(SERVICE_NAME=XE)));" +
              "User Id=CAR GALLERY;Password=456;";
        int ID;
        byte[] img;
        public UpdateCustm(int iD)
        {
            InitializeComponent();
            ID = iD;
        }

        private void UpdateCustm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            CustomerDash customerDash = new CustomerDash(ID);
            this.Hide();
            customerDash.Show();
        }

        private void UpdateCustm_Load(object sender, EventArgs e)
        {
            Customers CD = new Customers();
            CustomerData cd = new CustomerData();
            cd = CD.MyData(ID);
            user_box.Text = cd.GetUsername();
            pass_box.Text = cd.GetPassword();
            name_box.Text = cd.GetFullName();
            mail_box.Text = cd.GetEmail();
            no_box.Text = cd.GetPhone();

            if (pic_Box.Image != null)
                pic_Box.Image.Dispose();
            OracleConnection con = new OracleConnection(ConnectionString);
            con.Open();
            String query = "SELECT Picture FROM CustomerPictures WHERE CustomerID=" + ID + " ";


            OracleCommand cmd = new OracleCommand(query, con);
            OracleDataReader reader = cmd.ExecuteReader();
            if (!(reader.HasRows))
            {
                MessageBox.Show("No Image Stored");
            }
            else
            {
                while (reader.Read())
                {

                    MemoryStream ms = new MemoryStream((byte[])reader["Picture"]);
                    pic_Box.Image = System.Drawing.Image.FromStream(ms);
                    pic_Box.SizeMode = PictureBoxSizeMode.StretchImage;

                }
            }

            con.Close();
        }

        private void update_btn_Click(object sender, EventArgs e)
        {
            Customers CD = new Customers();
            CustomerData cd = new CustomerData(user_box.Text.ToString(), pass_box.Text.ToString(),
            name_box.Text.ToString(), mail_box.Text.ToString(), no_box.Text.ToString());
            cd.SetCustomerId(ID);
            CD.UpdateDataFromLists(cd);
            try
            {
                OracleConnection con = new OracleConnection(ConnectionString);
                con.Open();
                String query = "Update CustomerPictures Set Picture=:imag where CustomerID=:ID";

                OracleParameter picparameter = new OracleParameter();


                picparameter.OracleType = OracleType.Blob;

                picparameter.ParameterName = "imag";

                picparameter.Value = img.ToArray();

                OracleCommand cmd = new OracleCommand(query, con);
                cmd.Parameters.Add(picparameter);
                cmd.Parameters.Add(new OracleParameter("ID", ID));

                cmd.ExecuteNonQuery();
                MessageBox.Show("Data Updated Successfully");
                CustomerDash customer = new CustomerDash(ID);
                this.Hide();
                customer.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void upload_btn_Click(object sender, EventArgs e)
        {
            if (pic_Box.Image != null)
                pic_Box.Image.Dispose();
            try
            {
                OracleConnection con = new OracleConnection(ConnectionString);


                openFileDialog1.InitialDirectory = @"C:\";
                openFileDialog1.Filter = "[JPG,JPEG]|*.jpg; *.png";
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    FileStream FS = new FileStream(@openFileDialog1.FileName, FileMode.Open, FileAccess.Read);
                    img = new byte[FS.Length];
                    FS.Read(img, 0, Convert.ToInt32(FS.Length));
                    pic_Box.Image = Image.FromFile(openFileDialog1.FileName);
                    pic_Box.SizeMode = PictureBoxSizeMode.StretchImage;
                    MessageBox.Show("Picture Uploaded");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
