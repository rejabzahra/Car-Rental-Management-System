﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace Car_Gallery
{
    internal class RentalsData
    {
        int RentalId;
        int CustomerId;
        int CarId;
        string RentalDate;
        string ReturnDate;
        string RentalStatus;
        public RentalsData( int customerId, int carId)
        {
            RentalId = 0;
            CustomerId = customerId;
            CarId = carId;
            RentalDate = "";
            ReturnDate = "";
            RentalStatus = "";
        }
        public RentalsData() 
        {
            RentalId = 0;
            CustomerId = 0;
            CarId = 0;
            RentalDate = "";
            ReturnDate = "";
            RentalStatus = "";
        }
        public void SetRentalId(int rentalId)
        {
            RentalId = rentalId;
        }
        public int GetRentalId()
        {
            return RentalId;
        }
        public void SetCustomer(int cusid)
        {
            CustomerId = cusid;
        }
        public int GetCustomer()
        {
            return CustomerId;
        }
        public void SetCarId(int carId)
        {
            CarId = carId;
        }
        public int GetCarId()
        {
            return CarId;
        }
        public void SetRentalDate(string rentalDate)
        {
            RentalDate = rentalDate;
        }
        public string GetRentalDated()
        {
            return RentalDate;
        }
        public void SetReturnDate(string returnDate)
        {
            ReturnDate = returnDate;
        }
        public string GetReturnDate()
        {
            return ReturnDate;
        }
        public void SetRentalStatus(string rentalStatus)
        {
            RentalStatus = rentalStatus;
        }
        public string GetRentalStatus()
        {
            return RentalStatus;
        }
    }
}
