﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Gallery
{
    public partial class AddCar : Form
    {
        int ID;
        public AddCar( int id)
        {
            InitializeComponent();
           
            ID = id;
        }

        private void AddCar_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void name_lbl_Click(object sender, EventArgs e)
        {

        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminDash adminDash = new AdminDash(ID);
            adminDash.Show();
        }

        private void add_btn_Click(object sender, EventArgs e)

        {
            CarsData C = new CarsData(name_box.Text, noplate_box.Text, color_box.Text, Convert.ToInt32(rentalprice_box.Text), model_box.Text);
            Car c=new Car();
            c.InsertDataIntoOracle(C);
                
            MessageBox.Show("Car Added Successfully");
            this.Hide();
            AddCar add = new AddCar(ID);
            add.Show();
        }

        private void name_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void AddCar_Load(object sender, EventArgs e)
        {

        }
    }
}
