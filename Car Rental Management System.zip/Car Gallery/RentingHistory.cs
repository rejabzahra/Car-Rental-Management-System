﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Gallery
{
    public partial class RentingHistory : Form
    {
        int ID;
        public RentingHistory(int iD)
        {
            InitializeComponent();
            ID = iD;
        }

        private void RentingHistory_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerDash customerDash = new CustomerDash(ID);
            customerDash.Show();
        }

        private void RentingHistory_Load(object sender, EventArgs e)
        {
            Rental rental = new Rental();
            history_grdv.DataSource=rental.RentalHistory(ID);
        }
    }
}
