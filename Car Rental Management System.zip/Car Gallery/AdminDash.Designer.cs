﻿namespace Car_Gallery
{
    partial class AdminDash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminDash));
            this.car_panel = new System.Windows.Forms.Panel();
            this.admin_lbl = new System.Windows.Forms.Label();
            this.add_btn = new System.Windows.Forms.Button();
            this.rem_btn = new System.Windows.Forms.Button();
            this.rented_btn = new System.Windows.Forms.Button();
            this.upd_btn = new System.Windows.Forms.Button();
            this.search_btn = new System.Windows.Forms.Button();
            this.view_btn = new System.Windows.Forms.Button();
            this.uvail_btn = new System.Windows.Forms.Button();
            this.logout_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // car_panel
            // 
            this.car_panel.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.car_panel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("car_panel.BackgroundImage")));
            this.car_panel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.car_panel.Location = new System.Drawing.Point(852, 96);
            this.car_panel.Name = "car_panel";
            this.car_panel.Size = new System.Drawing.Size(1062, 927);
            this.car_panel.TabIndex = 0;
            // 
            // admin_lbl
            // 
            this.admin_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.admin_lbl.AutoSize = true;
            this.admin_lbl.BackColor = System.Drawing.Color.Transparent;
            this.admin_lbl.Font = new System.Drawing.Font("Impact", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.admin_lbl.ForeColor = System.Drawing.Color.White;
            this.admin_lbl.Location = new System.Drawing.Point(86, 18);
            this.admin_lbl.Name = "admin_lbl";
            this.admin_lbl.Size = new System.Drawing.Size(800, 117);
            this.admin_lbl.TabIndex = 20;
            this.admin_lbl.Text = "*Admin DashBoard*";
            this.admin_lbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // add_btn
            // 
            this.add_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.add_btn.BackColor = System.Drawing.Color.Silver;
            this.add_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_btn.Location = new System.Drawing.Point(561, 161);
            this.add_btn.Name = "add_btn";
            this.add_btn.Size = new System.Drawing.Size(236, 70);
            this.add_btn.TabIndex = 22;
            this.add_btn.Text = "Add Car";
            this.add_btn.UseVisualStyleBackColor = false;
            this.add_btn.Click += new System.EventHandler(this.add_btn_Click);
            // 
            // rem_btn
            // 
            this.rem_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rem_btn.BackColor = System.Drawing.Color.Silver;
            this.rem_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rem_btn.Location = new System.Drawing.Point(118, 540);
            this.rem_btn.Name = "rem_btn";
            this.rem_btn.Size = new System.Drawing.Size(321, 70);
            this.rem_btn.TabIndex = 23;
            this.rem_btn.Text = "Remove/Update Car";
            this.rem_btn.UseVisualStyleBackColor = false;
            this.rem_btn.Click += new System.EventHandler(this.rem_btn_Click);
            // 
            // rented_btn
            // 
            this.rented_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rented_btn.BackColor = System.Drawing.Color.Silver;
            this.rented_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rented_btn.Location = new System.Drawing.Point(401, 802);
            this.rented_btn.Name = "rented_btn";
            this.rented_btn.Size = new System.Drawing.Size(236, 70);
            this.rented_btn.TabIndex = 24;
            this.rented_btn.Text = "Rented Cars";
            this.rented_btn.UseVisualStyleBackColor = false;
            this.rented_btn.Click += new System.EventHandler(this.rented_btn_Click);
            // 
            // upd_btn
            // 
            this.upd_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.upd_btn.BackColor = System.Drawing.Color.Silver;
            this.upd_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.upd_btn.Location = new System.Drawing.Point(561, 920);
            this.upd_btn.Name = "upd_btn";
            this.upd_btn.Size = new System.Drawing.Size(236, 70);
            this.upd_btn.TabIndex = 25;
            this.upd_btn.Text = "Update Profile";
            this.upd_btn.UseVisualStyleBackColor = false;
            this.upd_btn.Click += new System.EventHandler(this.upd_btn_Click);
            // 
            // search_btn
            // 
            this.search_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.search_btn.BackColor = System.Drawing.Color.Silver;
            this.search_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search_btn.Location = new System.Drawing.Point(401, 278);
            this.search_btn.Name = "search_btn";
            this.search_btn.Size = new System.Drawing.Size(236, 70);
            this.search_btn.TabIndex = 26;
            this.search_btn.Text = "Search Car";
            this.search_btn.UseVisualStyleBackColor = false;
            this.search_btn.Click += new System.EventHandler(this.search_btn_Click);
            // 
            // view_btn
            // 
            this.view_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.view_btn.BackColor = System.Drawing.Color.Silver;
            this.view_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.view_btn.Location = new System.Drawing.Point(242, 397);
            this.view_btn.Name = "view_btn";
            this.view_btn.Size = new System.Drawing.Size(236, 70);
            this.view_btn.TabIndex = 27;
            this.view_btn.Text = "View Cars";
            this.view_btn.UseVisualStyleBackColor = false;
            this.view_btn.Click += new System.EventHandler(this.view_btn_Click);
            // 
            // uvail_btn
            // 
            this.uvail_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.uvail_btn.BackColor = System.Drawing.Color.Silver;
            this.uvail_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uvail_btn.Location = new System.Drawing.Point(242, 676);
            this.uvail_btn.Name = "uvail_btn";
            this.uvail_btn.Size = new System.Drawing.Size(236, 70);
            this.uvail_btn.TabIndex = 28;
            this.uvail_btn.Text = "Available Cars";
            this.uvail_btn.UseVisualStyleBackColor = false;
            this.uvail_btn.Click += new System.EventHandler(this.uvail_btn_Click);
            // 
            // logout_btn
            // 
            this.logout_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.logout_btn.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.logout_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("logout_btn.BackgroundImage")));
            this.logout_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.logout_btn.Location = new System.Drawing.Point(12, 968);
            this.logout_btn.Name = "logout_btn";
            this.logout_btn.Size = new System.Drawing.Size(52, 47);
            this.logout_btn.TabIndex = 29;
            this.logout_btn.UseVisualStyleBackColor = false;
            this.logout_btn.Click += new System.EventHandler(this.logout_btn_Click);
            // 
            // AdminDash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1723, 1027);
            this.Controls.Add(this.logout_btn);
            this.Controls.Add(this.uvail_btn);
            this.Controls.Add(this.view_btn);
            this.Controls.Add(this.search_btn);
            this.Controls.Add(this.upd_btn);
            this.Controls.Add(this.rented_btn);
            this.Controls.Add(this.rem_btn);
            this.Controls.Add(this.add_btn);
            this.Controls.Add(this.admin_lbl);
            this.Controls.Add(this.car_panel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AdminDash";
            this.Text = "AdminDashBoard";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AdminDash_FormClosing);
            this.Load += new System.EventHandler(this.AdminDash_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel car_panel;
        private System.Windows.Forms.Label admin_lbl;
        private System.Windows.Forms.Button add_btn;
        private System.Windows.Forms.Button rem_btn;
        private System.Windows.Forms.Button rented_btn;
        private System.Windows.Forms.Button upd_btn;
        private System.Windows.Forms.Button search_btn;
        private System.Windows.Forms.Button view_btn;
        private System.Windows.Forms.Button uvail_btn;
        private System.Windows.Forms.Button logout_btn;
    }
}