﻿namespace Car_Gallery
{
    partial class RentedCars
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RentedCars));
            this.cars_grdv = new System.Windows.Forms.DataGridView();
            this.rented_lbl = new System.Windows.Forms.Label();
            this.back_btn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.cars_grdv)).BeginInit();
            this.SuspendLayout();
            // 
            // cars_grdv
            // 
            this.cars_grdv.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cars_grdv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.cars_grdv.BackgroundColor = System.Drawing.Color.White;
            this.cars_grdv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cars_grdv.Location = new System.Drawing.Point(52, 232);
            this.cars_grdv.Name = "cars_grdv";
            this.cars_grdv.RowHeadersWidth = 62;
            this.cars_grdv.RowTemplate.Height = 28;
            this.cars_grdv.Size = new System.Drawing.Size(1810, 661);
            this.cars_grdv.TabIndex = 47;
            this.cars_grdv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.cars_grdv_CellContentClick);
            // 
            // rented_lbl
            // 
            this.rented_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rented_lbl.AutoSize = true;
            this.rented_lbl.BackColor = System.Drawing.Color.Transparent;
            this.rented_lbl.Font = new System.Drawing.Font("Impact", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rented_lbl.ForeColor = System.Drawing.Color.White;
            this.rented_lbl.Location = new System.Drawing.Point(650, 19);
            this.rented_lbl.Name = "rented_lbl";
            this.rented_lbl.Size = new System.Drawing.Size(580, 117);
            this.rented_lbl.TabIndex = 46;
            this.rented_lbl.Text = "*Rented Cars*";
            this.rented_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // back_btn
            // 
            this.back_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.back_btn.BackColor = System.Drawing.Color.White;
            this.back_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back_btn.Location = new System.Drawing.Point(39, 30);
            this.back_btn.Name = "back_btn";
            this.back_btn.Size = new System.Drawing.Size(132, 46);
            this.back_btn.TabIndex = 49;
            this.back_btn.Text = "Back";
            this.back_btn.UseVisualStyleBackColor = false;
            this.back_btn.Click += new System.EventHandler(this.back_btn_Click);
            // 
            // RentedCars
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1924, 925);
            this.Controls.Add(this.back_btn);
            this.Controls.Add(this.cars_grdv);
            this.Controls.Add(this.rented_lbl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "RentedCars";
            this.Text = "RentedCars";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.RentedCars_FormClosing);
            this.Load += new System.EventHandler(this.RentedCars_Load);
            ((System.ComponentModel.ISupportInitialize)(this.cars_grdv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView cars_grdv;
        private System.Windows.Forms.Label rented_lbl;
        private System.Windows.Forms.Button back_btn;
    }
}