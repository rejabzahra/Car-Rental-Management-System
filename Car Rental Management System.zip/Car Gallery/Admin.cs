﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using Oracle.ManagedDataAccess.Client;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Collections;
using System.Data;

namespace Car_Gallery
{
    internal class Admin
    {
        public string ConnectionString = "Data Source=(DESCRIPTION=" +
              "(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))" +
              "(CONNECT_DATA=(SERVICE_NAME=XE)));" +
              "User Id=CAR GALLERY;Password=456;";
        public Admin()
        {
           
        }
        public void UpdateDataFromLists(AdminData A)
        {
            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionString))
                {
                    connection.Open();
                    string query = "UPDATE Admin SET Username = :username, Password = :password, FullName = :fullName, Email = :email, Phone = :contactno WHERE AdminID = :ID";
                    OracleCommand cmd = new OracleCommand(query, connection);
                    cmd.Parameters.Add(new OracleParameter("username", A.GetUsername()));
                    cmd.Parameters.Add(new OracleParameter("password", A.GetPassword()));
                    cmd.Parameters.Add(new OracleParameter("fullName", A.GetFullName()));
                    cmd.Parameters.Add(new OracleParameter("email", A.GetEmail()));
                    cmd.Parameters.Add(new OracleParameter("contactno", A.GetPhone()));
                    cmd.Parameters.Add(new OracleParameter("ID", A.GetAdminId()));
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error18: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public AdminData SearchOInBasisOfUsernamePassword(string username, string password)
        {
            AdminData A = new AdminData();
            try
            {
                string query = "SELECT * FROM Admin Where Username='" + username + "' AND Password ='" + password + "'";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    conn.Open();
                    OracleDataAdapter adapter = new OracleDataAdapter(query, conn);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    foreach (DataRow row in table.Rows)
                    {
                        A.SetAdminId(Convert.ToInt32(row["AdminID"]));
                        A.SetUsername(row["Username"].ToString());
                        A.SetPassword(row["Password"].ToString());
                        A.SetFullName(row["FullName"].ToString());
                        A.SetEmail(row["Email"].ToString());
                        A.SetPhone(row["Phone"].ToString());
                    }
                }
                return A;


            }
            catch (Exception ex)
            {
                MessageBox.Show("Error112: " + ex.Message);
                return A;

            }
        }
        public AdminData MyData(int id)
        {
            AdminData A = new AdminData();
            try
            {
                string query = "SELECT * FROM Admin Where AdminID = " + id + "";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    conn.Open();
                    OracleDataAdapter adapter = new OracleDataAdapter(query, conn);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    foreach (DataRow row in table.Rows)
                    {
                        A.SetAdminId(Convert.ToInt32(row["AdminID"]));
                        A.SetUsername(row["Username"].ToString());
                        A.SetPassword(row["Password"].ToString());
                        A.SetFullName(row["FullName"].ToString());
                        A.SetEmail(row["Email"].ToString());
                        A.SetPhone(row["Phone"].ToString());
                    }
                }
                return A;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                return A;
            }
        }
    }
}
