﻿namespace Car_Gallery
{
    partial class CustomerDash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomerDash));
            this.custm_lbl = new System.Windows.Forms.Label();
            this.rent_btn = new System.Windows.Forms.Button();
            this.upd_btn = new System.Windows.Forms.Button();
            this.history_btn = new System.Windows.Forms.Button();
            this.avail_btn = new System.Windows.Forms.Button();
            this.return_btn = new System.Windows.Forms.Button();
            this.logout_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // custm_lbl
            // 
            this.custm_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.custm_lbl.AutoSize = true;
            this.custm_lbl.BackColor = System.Drawing.Color.Transparent;
            this.custm_lbl.Font = new System.Drawing.Font("Impact", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.custm_lbl.ForeColor = System.Drawing.Color.White;
            this.custm_lbl.Location = new System.Drawing.Point(240, 61);
            this.custm_lbl.Name = "custm_lbl";
            this.custm_lbl.Size = new System.Drawing.Size(934, 117);
            this.custm_lbl.TabIndex = 21;
            this.custm_lbl.Text = "*Customer DashBoard*";
            this.custm_lbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // rent_btn
            // 
            this.rent_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rent_btn.BackColor = System.Drawing.Color.Silver;
            this.rent_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rent_btn.Location = new System.Drawing.Point(259, 334);
            this.rent_btn.Name = "rent_btn";
            this.rent_btn.Size = new System.Drawing.Size(255, 70);
            this.rent_btn.TabIndex = 23;
            this.rent_btn.Text = "Rent A Car";
            this.rent_btn.UseVisualStyleBackColor = false;
            this.rent_btn.Click += new System.EventHandler(this.rent_btn_Click);
            // 
            // upd_btn
            // 
            this.upd_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.upd_btn.BackColor = System.Drawing.Color.Silver;
            this.upd_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.upd_btn.Location = new System.Drawing.Point(594, 496);
            this.upd_btn.Name = "upd_btn";
            this.upd_btn.Size = new System.Drawing.Size(236, 70);
            this.upd_btn.TabIndex = 24;
            this.upd_btn.Text = "Update Profile";
            this.upd_btn.UseVisualStyleBackColor = false;
            this.upd_btn.Click += new System.EventHandler(this.upd_btn_Click);
            // 
            // history_btn
            // 
            this.history_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.history_btn.BackColor = System.Drawing.Color.Silver;
            this.history_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.history_btn.Location = new System.Drawing.Point(894, 664);
            this.history_btn.Name = "history_btn";
            this.history_btn.Size = new System.Drawing.Size(250, 70);
            this.history_btn.TabIndex = 25;
            this.history_btn.Text = "Renting History";
            this.history_btn.UseVisualStyleBackColor = false;
            this.history_btn.Click += new System.EventHandler(this.history_btn_Click);
            // 
            // avail_btn
            // 
            this.avail_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.avail_btn.BackColor = System.Drawing.Color.Silver;
            this.avail_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.avail_btn.Location = new System.Drawing.Point(259, 664);
            this.avail_btn.Name = "avail_btn";
            this.avail_btn.Size = new System.Drawing.Size(255, 70);
            this.avail_btn.TabIndex = 26;
            this.avail_btn.Text = "Available Cars";
            this.avail_btn.UseVisualStyleBackColor = false;
            this.avail_btn.Click += new System.EventHandler(this.avail_btn_Click);
            // 
            // return_btn
            // 
            this.return_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.return_btn.BackColor = System.Drawing.Color.Silver;
            this.return_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.return_btn.Location = new System.Drawing.Point(894, 334);
            this.return_btn.Name = "return_btn";
            this.return_btn.Size = new System.Drawing.Size(250, 70);
            this.return_btn.TabIndex = 27;
            this.return_btn.Text = "Return Car";
            this.return_btn.UseVisualStyleBackColor = false;
            this.return_btn.Click += new System.EventHandler(this.return_btn_Click);
            // 
            // logout_btn
            // 
            this.logout_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.logout_btn.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.logout_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("logout_btn.BackgroundImage")));
            this.logout_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.logout_btn.Location = new System.Drawing.Point(1327, 837);
            this.logout_btn.Name = "logout_btn";
            this.logout_btn.Size = new System.Drawing.Size(52, 47);
            this.logout_btn.TabIndex = 28;
            this.logout_btn.UseVisualStyleBackColor = false;
            this.logout_btn.Click += new System.EventHandler(this.logout_btn_Click);
            // 
            // CustomerDash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1412, 896);
            this.Controls.Add(this.logout_btn);
            this.Controls.Add(this.return_btn);
            this.Controls.Add(this.avail_btn);
            this.Controls.Add(this.history_btn);
            this.Controls.Add(this.upd_btn);
            this.Controls.Add(this.rent_btn);
            this.Controls.Add(this.custm_lbl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CustomerDash";
            this.Text = "CustomerDash";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CustomerDash_FormClosing);
            this.Load += new System.EventHandler(this.CustomerDash_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label custm_lbl;
        private System.Windows.Forms.Button rent_btn;
        private System.Windows.Forms.Button upd_btn;
        private System.Windows.Forms.Button history_btn;
        private System.Windows.Forms.Button avail_btn;
        private System.Windows.Forms.Button return_btn;
        private System.Windows.Forms.Button logout_btn;
    }
}