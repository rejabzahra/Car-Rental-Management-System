﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OracleClient;

namespace Car_Gallery
{
    public partial class UpdateAdmin : Form
    {
        public string ConnectionString = "Data Source=(DESCRIPTION=" +
              "(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))" +
              "(CONNECT_DATA=(SERVICE_NAME=XE)));" +
              "User Id=CAR GALLERY;Password=456;";
        int ID;
        byte[] img;
        public UpdateAdmin( int iD)
        {
            InitializeComponent();
            ID = iD;
        }

        private void UpdateAdmin_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminDash adminDash = new AdminDash(ID);
            adminDash.Show();
        }

        private void UpdateAdmin_Load(object sender, EventArgs e)
        {
            Admin A=new Admin();
            AdminData a=new AdminData();
            a=A.MyData(ID);
            user_box.Text =a.GetUsername();
            pass_box.Text = a.GetPassword();
            name_box.Text = a.GetFullName();
            mail_box.Text =a.GetEmail();
            no_box.Text = a.GetPhone();
            if (pic_Box.Image != null)
                pic_Box.Image.Dispose();
            OracleConnection con = new OracleConnection(ConnectionString);
            con.Open();
            String query = "SELECT Picture FROM AdminPictures WHERE AdminID=" + ID + " ";


            OracleCommand cmd = new OracleCommand(query, con);
            OracleDataReader reader = cmd.ExecuteReader();
            if (!(reader.HasRows))
            {
                MessageBox.Show("No Images Stored");
            }
            else
            {
                while (reader.Read())
                {

                    MemoryStream ms = new MemoryStream((byte[])reader["Picture"]);
                    pic_Box.Image = System.Drawing.Image.FromStream(ms);
                    pic_Box.SizeMode = PictureBoxSizeMode.StretchImage;

                }
            }

            con.Close();
        }
        private void update_btn_Click(object sender, EventArgs e)
        {
            Admin A = new Admin();
            AdminData a = new AdminData(user_box.Text.ToString(), pass_box.Text.ToString(),
            name_box.Text.ToString(), mail_box.Text.ToString(), no_box.Text.ToString());
            a.SetAdminId(ID);
            A.UpdateDataFromLists(a);
           
            try
            {
                OracleConnection con = new OracleConnection(ConnectionString);
                con.Open();
                String query = "Update AdminPictures Set Picture=:imag where AdminID=:ID";

                OracleParameter picparameter = new OracleParameter();


                picparameter.OracleType = OracleType.Blob;

                picparameter.ParameterName = "imag";

                picparameter.Value = img.ToArray();

                OracleCommand cmd = new OracleCommand(query, con);
                cmd.Parameters.Add(picparameter);
                cmd.Parameters.Add(new OracleParameter("ID", ID));

                cmd.ExecuteNonQuery();
                MessageBox.Show("Data Updated Successfully");
                AdminDash admin = new AdminDash( ID);
                admin.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void upload_btn_Click(object sender, EventArgs e)
        {
            if (pic_Box.Image != null)
                pic_Box.Image.Dispose();
            try
            {
                OracleConnection con = new OracleConnection(ConnectionString);


                openFileDialog1.InitialDirectory = @"C:\";
                openFileDialog1.Filter = "[JPG,JPEG]|*.jpg; *.png";
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    FileStream FS = new FileStream(@openFileDialog1.FileName, FileMode.Open, FileAccess.Read);
                    img = new byte[FS.Length];
                    FS.Read(img, 0, Convert.ToInt32(FS.Length));
                    pic_Box.Image = Image.FromFile(openFileDialog1.FileName);
                    pic_Box.SizeMode = PictureBoxSizeMode.StretchImage;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
