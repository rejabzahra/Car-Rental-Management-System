﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Gallery
{
    public partial class AvailableCars : Form
    {
        int ID;
        public AvailableCars( int iD)
        {
            InitializeComponent();
            ID = iD;
        }

        private void AvailableCars_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminDash adminDash = new AdminDash(ID);
            adminDash.Show();
        }

        private void AvailableCars_Load(object sender, EventArgs e)
        {
            Car c = new Car();
            cars_grdv.DataSource = c.AvailCars();
        }
    }
}
