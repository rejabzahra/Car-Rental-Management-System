﻿namespace Car_Gallery
{
    partial class CustomerLogIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomerLogIn));
            this.create_btn = new System.Windows.Forms.Button();
            this.login_btn = new System.Windows.Forms.Button();
            this.pass_box = new System.Windows.Forms.TextBox();
            this.name_box = new System.Windows.Forms.TextBox();
            this.acc_lbl = new System.Windows.Forms.Label();
            this.pass_lbl = new System.Windows.Forms.Label();
            this.name_lbl = new System.Windows.Forms.Label();
            this.cstm_lbl = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.back_btn = new System.Windows.Forms.Button();
            this.pass_check = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // create_btn
            // 
            this.create_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.create_btn.BackColor = System.Drawing.Color.White;
            this.create_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.create_btn.Location = new System.Drawing.Point(1207, 713);
            this.create_btn.Name = "create_btn";
            this.create_btn.Size = new System.Drawing.Size(156, 50);
            this.create_btn.TabIndex = 16;
            this.create_btn.Text = "Create!";
            this.create_btn.UseVisualStyleBackColor = false;
            this.create_btn.Click += new System.EventHandler(this.create_btn_Click);
            // 
            // login_btn
            // 
            this.login_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.login_btn.BackColor = System.Drawing.Color.White;
            this.login_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.login_btn.Location = new System.Drawing.Point(1026, 595);
            this.login_btn.Name = "login_btn";
            this.login_btn.Size = new System.Drawing.Size(136, 56);
            this.login_btn.TabIndex = 15;
            this.login_btn.Text = "LogIn";
            this.login_btn.UseVisualStyleBackColor = false;
            this.login_btn.Click += new System.EventHandler(this.login_btn_Click);
            // 
            // pass_box
            // 
            this.pass_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pass_box.BackColor = System.Drawing.Color.White;
            this.pass_box.Location = new System.Drawing.Point(1102, 449);
            this.pass_box.Name = "pass_box";
            this.pass_box.Size = new System.Drawing.Size(312, 26);
            this.pass_box.TabIndex = 14;
            this.pass_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // name_box
            // 
            this.name_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.name_box.BackColor = System.Drawing.Color.White;
            this.name_box.Location = new System.Drawing.Point(1102, 312);
            this.name_box.Multiline = true;
            this.name_box.Name = "name_box";
            this.name_box.Size = new System.Drawing.Size(312, 36);
            this.name_box.TabIndex = 13;
            this.name_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // acc_lbl
            // 
            this.acc_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.acc_lbl.AutoSize = true;
            this.acc_lbl.BackColor = System.Drawing.Color.Transparent;
            this.acc_lbl.Font = new System.Drawing.Font("Microsoft YaHei", 14F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acc_lbl.ForeColor = System.Drawing.Color.White;
            this.acc_lbl.Location = new System.Drawing.Point(835, 727);
            this.acc_lbl.Name = "acc_lbl";
            this.acc_lbl.Size = new System.Drawing.Size(336, 36);
            this.acc_lbl.TabIndex = 12;
            this.acc_lbl.Text = "Don\'t Have an Account?";
            this.acc_lbl.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // pass_lbl
            // 
            this.pass_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pass_lbl.AutoSize = true;
            this.pass_lbl.BackColor = System.Drawing.Color.Transparent;
            this.pass_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pass_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pass_lbl.Location = new System.Drawing.Point(794, 444);
            this.pass_lbl.Name = "pass_lbl";
            this.pass_lbl.Size = new System.Drawing.Size(242, 36);
            this.pass_lbl.TabIndex = 11;
            this.pass_lbl.Text = "Enter Password:";
            this.pass_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // name_lbl
            // 
            this.name_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.name_lbl.AutoSize = true;
            this.name_lbl.BackColor = System.Drawing.Color.Transparent;
            this.name_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.name_lbl.Location = new System.Drawing.Point(794, 312);
            this.name_lbl.Name = "name_lbl";
            this.name_lbl.Size = new System.Drawing.Size(254, 36);
            this.name_lbl.TabIndex = 10;
            this.name_lbl.Text = "Enter UserName:";
            this.name_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cstm_lbl
            // 
            this.cstm_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cstm_lbl.AutoSize = true;
            this.cstm_lbl.BackColor = System.Drawing.Color.Transparent;
            this.cstm_lbl.Font = new System.Drawing.Font("Impact", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cstm_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cstm_lbl.Location = new System.Drawing.Point(719, 34);
            this.cstm_lbl.Name = "cstm_lbl";
            this.cstm_lbl.Size = new System.Drawing.Size(770, 117);
            this.cstm_lbl.TabIndex = 9;
            this.cstm_lbl.Text = "*CUSTOMER LOGIN*";
            this.cstm_lbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(-3, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(700, 1020);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint_1);
            // 
            // back_btn
            // 
            this.back_btn.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.back_btn.BackColor = System.Drawing.Color.White;
            this.back_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back_btn.Location = new System.Drawing.Point(970, 918);
            this.back_btn.Name = "back_btn";
            this.back_btn.Size = new System.Drawing.Size(287, 60);
            this.back_btn.TabIndex = 17;
            this.back_btn.Text = "Back to USERS";
            this.back_btn.UseVisualStyleBackColor = false;
            this.back_btn.Click += new System.EventHandler(this.back_btn_Click);
            // 
            // pass_check
            // 
            this.pass_check.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pass_check.AutoSize = true;
            this.pass_check.BackColor = System.Drawing.Color.Transparent;
            this.pass_check.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pass_check.ForeColor = System.Drawing.Color.White;
            this.pass_check.Location = new System.Drawing.Point(1102, 515);
            this.pass_check.Name = "pass_check";
            this.pass_check.Size = new System.Drawing.Size(213, 33);
            this.pass_check.TabIndex = 18;
            this.pass_check.Text = "Show Password";
            this.pass_check.UseVisualStyleBackColor = false;
            this.pass_check.CheckedChanged += new System.EventHandler(this.pass_check_CheckedChanged);
            // 
            // CustomerLogIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1488, 1011);
            this.Controls.Add(this.pass_check);
            this.Controls.Add(this.back_btn);
            this.Controls.Add(this.create_btn);
            this.Controls.Add(this.login_btn);
            this.Controls.Add(this.pass_box);
            this.Controls.Add(this.name_box);
            this.Controls.Add(this.acc_lbl);
            this.Controls.Add(this.pass_lbl);
            this.Controls.Add(this.name_lbl);
            this.Controls.Add(this.cstm_lbl);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CustomerLogIn";
            this.Text = "CustomerLogIn";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CustomerLogIn_FormClosing);
            this.Load += new System.EventHandler(this.CustomerLogIn_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button create_btn;
        private System.Windows.Forms.Button login_btn;
        private System.Windows.Forms.TextBox pass_box;
        private System.Windows.Forms.TextBox name_box;
        private System.Windows.Forms.Label acc_lbl;
        private System.Windows.Forms.Label pass_lbl;
        private System.Windows.Forms.Label name_lbl;
        private System.Windows.Forms.Label cstm_lbl;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button back_btn;
        private System.Windows.Forms.CheckBox pass_check;
    }
}