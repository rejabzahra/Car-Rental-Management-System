﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Gallery
{
    public partial class RentedCars : Form
    {
        int ID;
        public RentedCars( int iD)
        {
            InitializeComponent();
            ID = iD;
        }

        private void RentedCars_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void RentedCars_Load(object sender, EventArgs e)
        {
            Car C=new Car();
            cars_grdv.DataSource = C.RentedCars();
        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminDash adminDash = new AdminDash(ID);
            adminDash.Show();
        }

        private void cars_grdv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
