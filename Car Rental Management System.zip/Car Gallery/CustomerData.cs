﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Gallery
{
    internal class CustomerData:Person
    {
        int CustomerId;
       
        public CustomerData(string username, string password, string fullName, string email, string phone):base(username,password,fullName,email,phone)
        {
            CustomerId = 0;
            
        }
        public CustomerData():base()
        {
            CustomerId = 0;
            
        }
        public void SetCustomerId(int id)
        {
            CustomerId = id;
        }
        public int GetCustomerId()
        {
            return CustomerId;
        }
        public void SetPassword(string pass)
        {
            base.Setpassword(pass);
        }
        public string GetPassword()
        {
            return base.Getpassword();
        }
        public void SetUsername(string uname)
        {
            base.Setusername(uname);
        }
        public string GetUsername()
        {
            return base.Getusername();
        }
        public void SetEmail(string email)
        {
            base.Setemail(email);
        }
        public string GetEmail()
        {
            return base.Getemail();
        }
        public void SetFullName(string fname)
        {
            base.SetfullName(fname);
        }
        public string GetFullName()
        {
            return base.GetfullName();
        }
        public void SetPhone(string phonne)
        {
            base.Setphone(phonne);
        }
        public string GetPhone()
        {
            return base.Getphone();
        }
    }
}
