﻿namespace Car_Gallery
{
    partial class AddCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddCar));
            this.add_lbl = new System.Windows.Forms.Label();
            this.add_btn = new System.Windows.Forms.Button();
            this.name_box = new System.Windows.Forms.TextBox();
            this.color_lbl = new System.Windows.Forms.Label();
            this.noplate_box = new System.Windows.Forms.TextBox();
            this.noplate_lbl = new System.Windows.Forms.Label();
            this.color_box = new System.Windows.Forms.TextBox();
            this.name_lbl = new System.Windows.Forms.Label();
            this.rentalprice_box = new System.Windows.Forms.TextBox();
            this.rentalprice_lbl = new System.Windows.Forms.Label();
            this.model_box = new System.Windows.Forms.TextBox();
            this.model_lbl = new System.Windows.Forms.Label();
            this.back_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // add_lbl
            // 
            this.add_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.add_lbl.AutoSize = true;
            this.add_lbl.BackColor = System.Drawing.Color.Transparent;
            this.add_lbl.Font = new System.Drawing.Font("Impact", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_lbl.ForeColor = System.Drawing.Color.White;
            this.add_lbl.Location = new System.Drawing.Point(540, 40);
            this.add_lbl.Name = "add_lbl";
            this.add_lbl.Size = new System.Drawing.Size(405, 117);
            this.add_lbl.TabIndex = 22;
            this.add_lbl.Text = "*Add Car*";
            this.add_lbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // add_btn
            // 
            this.add_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.add_btn.BackColor = System.Drawing.Color.White;
            this.add_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_btn.Location = new System.Drawing.Point(670, 667);
            this.add_btn.Name = "add_btn";
            this.add_btn.Size = new System.Drawing.Size(165, 56);
            this.add_btn.TabIndex = 23;
            this.add_btn.Text = "ADD CAR";
            this.add_btn.UseVisualStyleBackColor = false;
            this.add_btn.Click += new System.EventHandler(this.add_btn_Click);
            // 
            // name_box
            // 
            this.name_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.name_box.BackColor = System.Drawing.Color.White;
            this.name_box.Location = new System.Drawing.Point(760, 223);
            this.name_box.Multiline = true;
            this.name_box.Name = "name_box";
            this.name_box.Size = new System.Drawing.Size(312, 45);
            this.name_box.TabIndex = 25;
            this.name_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.name_box.TextChanged += new System.EventHandler(this.name_box_TextChanged);
            // 
            // color_lbl
            // 
            this.color_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.color_lbl.AutoSize = true;
            this.color_lbl.BackColor = System.Drawing.Color.Transparent;
            this.color_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.color_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.color_lbl.Location = new System.Drawing.Point(452, 398);
            this.color_lbl.Name = "color_lbl";
            this.color_lbl.Size = new System.Drawing.Size(111, 36);
            this.color_lbl.TabIndex = 24;
            this.color_lbl.Text = "Color :";
            this.color_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.color_lbl.Click += new System.EventHandler(this.name_lbl_Click);
            // 
            // noplate_box
            // 
            this.noplate_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.noplate_box.BackColor = System.Drawing.Color.White;
            this.noplate_box.Location = new System.Drawing.Point(760, 306);
            this.noplate_box.Multiline = true;
            this.noplate_box.Name = "noplate_box";
            this.noplate_box.Size = new System.Drawing.Size(312, 45);
            this.noplate_box.TabIndex = 27;
            this.noplate_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // noplate_lbl
            // 
            this.noplate_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.noplate_lbl.AutoSize = true;
            this.noplate_lbl.BackColor = System.Drawing.Color.Transparent;
            this.noplate_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.noplate_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.noplate_lbl.Location = new System.Drawing.Point(452, 315);
            this.noplate_lbl.Name = "noplate_lbl";
            this.noplate_lbl.Size = new System.Drawing.Size(225, 36);
            this.noplate_lbl.TabIndex = 26;
            this.noplate_lbl.Text = "Number Plate :";
            this.noplate_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // color_box
            // 
            this.color_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.color_box.BackColor = System.Drawing.Color.White;
            this.color_box.Location = new System.Drawing.Point(760, 389);
            this.color_box.Multiline = true;
            this.color_box.Name = "color_box";
            this.color_box.Size = new System.Drawing.Size(312, 45);
            this.color_box.TabIndex = 29;
            this.color_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // name_lbl
            // 
            this.name_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.name_lbl.AutoSize = true;
            this.name_lbl.BackColor = System.Drawing.Color.Transparent;
            this.name_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.name_lbl.Location = new System.Drawing.Point(452, 232);
            this.name_lbl.Name = "name_lbl";
            this.name_lbl.Size = new System.Drawing.Size(114, 36);
            this.name_lbl.TabIndex = 28;
            this.name_lbl.Text = "Name :";
            this.name_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rentalprice_box
            // 
            this.rentalprice_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rentalprice_box.BackColor = System.Drawing.Color.White;
            this.rentalprice_box.Location = new System.Drawing.Point(760, 467);
            this.rentalprice_box.Multiline = true;
            this.rentalprice_box.Name = "rentalprice_box";
            this.rentalprice_box.Size = new System.Drawing.Size(312, 45);
            this.rentalprice_box.TabIndex = 31;
            this.rentalprice_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // rentalprice_lbl
            // 
            this.rentalprice_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rentalprice_lbl.AutoSize = true;
            this.rentalprice_lbl.BackColor = System.Drawing.Color.Transparent;
            this.rentalprice_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rentalprice_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.rentalprice_lbl.Location = new System.Drawing.Point(452, 476);
            this.rentalprice_lbl.Name = "rentalprice_lbl";
            this.rentalprice_lbl.Size = new System.Drawing.Size(204, 36);
            this.rentalprice_lbl.TabIndex = 30;
            this.rentalprice_lbl.Text = "Rental Price :";
            this.rentalprice_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // model_box
            // 
            this.model_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.model_box.BackColor = System.Drawing.Color.White;
            this.model_box.Location = new System.Drawing.Point(760, 552);
            this.model_box.Multiline = true;
            this.model_box.Name = "model_box";
            this.model_box.Size = new System.Drawing.Size(312, 45);
            this.model_box.TabIndex = 33;
            this.model_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // model_lbl
            // 
            this.model_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.model_lbl.AutoSize = true;
            this.model_lbl.BackColor = System.Drawing.Color.Transparent;
            this.model_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.model_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.model_lbl.Location = new System.Drawing.Point(452, 561);
            this.model_lbl.Name = "model_lbl";
            this.model_lbl.Size = new System.Drawing.Size(122, 36);
            this.model_lbl.TabIndex = 32;
            this.model_lbl.Text = "Model :";
            this.model_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // back_btn
            // 
            this.back_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.back_btn.BackColor = System.Drawing.Color.White;
            this.back_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back_btn.Location = new System.Drawing.Point(57, 40);
            this.back_btn.Name = "back_btn";
            this.back_btn.Size = new System.Drawing.Size(115, 46);
            this.back_btn.TabIndex = 49;
            this.back_btn.Text = "Back";
            this.back_btn.UseVisualStyleBackColor = false;
            this.back_btn.Click += new System.EventHandler(this.back_btn_Click);
            // 
            // AddCar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1509, 815);
            this.Controls.Add(this.back_btn);
            this.Controls.Add(this.model_box);
            this.Controls.Add(this.model_lbl);
            this.Controls.Add(this.rentalprice_box);
            this.Controls.Add(this.rentalprice_lbl);
            this.Controls.Add(this.color_box);
            this.Controls.Add(this.name_lbl);
            this.Controls.Add(this.noplate_box);
            this.Controls.Add(this.noplate_lbl);
            this.Controls.Add(this.name_box);
            this.Controls.Add(this.color_lbl);
            this.Controls.Add(this.add_btn);
            this.Controls.Add(this.add_lbl);
            this.DoubleBuffered = true;
            this.Name = "AddCar";
            this.Text = "AddCar";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AddCar_FormClosing);
            this.Load += new System.EventHandler(this.AddCar_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label add_lbl;
        private System.Windows.Forms.Button add_btn;
        private System.Windows.Forms.TextBox name_box;
        private System.Windows.Forms.Label color_lbl;
        private System.Windows.Forms.TextBox noplate_box;
        private System.Windows.Forms.Label noplate_lbl;
        private System.Windows.Forms.TextBox color_box;
        private System.Windows.Forms.Label name_lbl;
        private System.Windows.Forms.TextBox rentalprice_box;
        private System.Windows.Forms.Label rentalprice_lbl;
        private System.Windows.Forms.TextBox model_box;
        private System.Windows.Forms.Label model_lbl;
        private System.Windows.Forms.Button back_btn;
    }
}