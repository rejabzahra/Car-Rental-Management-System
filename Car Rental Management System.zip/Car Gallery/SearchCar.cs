﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Gallery
{
    public partial class SearchCar : Form
    {
        int ID;
        public SearchCar( int iD)
        {
            InitializeComponent();
            ID = iD;
        }

        private void SearchCar_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void SearchCar_Load(object sender, EventArgs e)
        {
            Car C = new Car();
            List<string> CarName = new List<string>();
            CarName = C.CarName();
            for (int i = 0; i < CarName.Count; i++)
            {
                name_cmbo.Items.Add(CarName[i]);
            }
            List<string> CarColor = new List<string>();
            CarColor = C.CarColor();
            for (int i = 0; i < CarColor.Count; i++)
            {
                color_cmbo.Items.Add(CarColor[i]);
            }
            List<int> CarPrice = new List<int>();
            CarPrice= C.CarPrice();
            for (int i = 0; i < CarPrice.Count; i++)
            {
                price_cmbo.Items.Add(CarPrice[i]);
            }

        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminDash adminDash = new AdminDash(ID);
            adminDash.Show();
        }

        private void name_cmbo_SelectedIndexChanged(object sender, EventArgs e)
        {
            Car C = new Car();
            if (price_cmbo.SelectedIndex != -1 && color_cmbo.SelectedIndex != -1)
            { cars_grdv.DataSource = C.SearchOnBasisOfNameColorRprice(color_cmbo.SelectedItem.ToString(),name_cmbo.SelectedItem.ToString(),Convert.ToInt32(price_cmbo.SelectedItem)); }
            else if(price_cmbo.SelectedIndex == -1 && color_cmbo.SelectedIndex != -1)
            {
                cars_grdv.DataSource = C.SearchOnBasisOfNameColor(color_cmbo.SelectedItem.ToString(), name_cmbo.SelectedItem.ToString());
            }
            else if(price_cmbo.SelectedIndex != -1 && color_cmbo.SelectedIndex == -1)
            {
                cars_grdv.DataSource = C.SearchOnBasisOfNameRPrize(name_cmbo.SelectedItem.ToString(), Convert.ToInt32(price_cmbo.SelectedItem));
            }
            else
            {
                cars_grdv.DataSource = C.SearchOnBasisOfName(name_cmbo.SelectedItem.ToString());

            }
        }
        private void price_cmbo_SelectedIndexChanged(object sender, EventArgs e)
        {
            Car C = new Car();
            if (name_cmbo.SelectedIndex != -1 && color_cmbo.SelectedIndex != -1)
            { cars_grdv.DataSource = C.SearchOnBasisOfNameColorRprice(color_cmbo.SelectedItem.ToString(), name_cmbo.SelectedItem.ToString(), Convert.ToInt32(price_cmbo.SelectedItem)); }
            else if (name_cmbo.SelectedIndex == -1 && color_cmbo.SelectedIndex != -1)
            {
                cars_grdv.DataSource = C.SearchOnBasisOfColorRPrize(color_cmbo.SelectedItem.ToString(), Convert.ToInt32(price_cmbo.SelectedItem));
            }
            else if (name_cmbo.SelectedIndex != -1 && color_cmbo.SelectedIndex == -1)
            {
                cars_grdv.DataSource = C.SearchOnBasisOfNameRPrize(name_cmbo.SelectedItem.ToString(), Convert.ToInt32(price_cmbo.SelectedItem));
            }
            else
            {
                cars_grdv.DataSource = C.SearchOnBasisOfRentalPrice(Convert.ToInt32(price_cmbo.SelectedItem));

            }
        }
        private void color_cmbo_SelectedIndexChanged(object sender, EventArgs e)
        {
            Car C = new Car();
            if (name_cmbo.SelectedIndex != -1 && price_cmbo.SelectedIndex != -1)
            { cars_grdv.DataSource = C.SearchOnBasisOfNameColorRprice(color_cmbo.SelectedItem.ToString(), name_cmbo.SelectedItem.ToString(), Convert.ToInt32(price_cmbo.SelectedItem)); }
            else if (name_cmbo.SelectedIndex == -1 && price_cmbo.SelectedIndex != -1)
            {
                cars_grdv.DataSource = C.SearchOnBasisOfColorRPrize(color_cmbo.SelectedItem.ToString(), Convert.ToInt32(price_cmbo.SelectedItem));
            }
            else if (name_cmbo.SelectedIndex != -1 && price_cmbo.SelectedIndex == -1)
            {
                cars_grdv.DataSource = C.SearchOnBasisOfNameColor(color_cmbo.SelectedItem.ToString(), name_cmbo.SelectedItem.ToString());
            }
            else
            {
                cars_grdv.DataSource = C.SearchOnBasisOfColor(color_cmbo.SelectedItem.ToString());

            }
        }
    }
}
