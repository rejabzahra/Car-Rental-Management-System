﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;
using Oracle.ManagedDataAccess.Client;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.Windows.Forms;
using System.Data;
using System.Net;
using System.Diagnostics;

namespace Car_Gallery
{
    internal class Car
    {
        public string ConnectionString = "Data Source=(DESCRIPTION=" +
              "(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))" +
              "(CONNECT_DATA=(SERVICE_NAME=XE)));" +
              "User Id=CAR GALLERY;Password=456;";

       
        public Car()
        {
           
        }
        
        public void  InsertDataIntoOracle(CarsData C)
        {
            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionString))
                {
                    connection.Open();
                    string query = "Insert into Cars (Name,NumberPlate,Color,RentalPrice,Model) values (:name,:numberPlate,:color,:rentalPrice,:model)";

                    OracleCommand cmd = new OracleCommand(query, connection);
                    cmd.Parameters.Add(new OracleParameter("name", C.GetName()));
                    cmd.Parameters.Add(new OracleParameter("numberPlate", C.GetNumberPalte()));
                    cmd.Parameters.Add(new OracleParameter("color", C.GetColor()));
                    cmd.Parameters.Add(new OracleParameter("rentalPrice", C.GetRentalPrize()));
                    cmd.Parameters.Add(new OracleParameter("model", C.GetModel()));

                    cmd.ExecuteNonQuery();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void RemoveDataFromLists(int carId)
        {
            try
            {
                string query = "Delete From Cars Where CARID=:carid";
                using (OracleConnection con = new OracleConnection(ConnectionString))
                {
                    con.Open();
                    OracleCommand cmd = new OracleCommand(query, con);
                    cmd.Parameters.Add(new OracleParameter("carid", carId));
                    cmd.ExecuteNonQuery();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        public void UpdateDataFromLists(CarsData C)
        {
            try
            {
                string query = "update Cars Set Name=:name,NumberPlate=:np,Color=:c,RentalPrice=:rp,Model=:m where CARID=:carid";
                using (OracleConnection con = new OracleConnection(ConnectionString))
                {
                    con.Open();
                    OracleCommand cmd = new OracleCommand(query, con);
                    cmd.Parameters.Add(new OracleParameter("name", C.GetName()));
                    cmd.Parameters.Add(new OracleParameter("np", C.GetNumberPalte()));
                    cmd.Parameters.Add(new OracleParameter("c", C.GetColor()));
                    cmd.Parameters.Add(new OracleParameter("rp", C.GetRentalPrize()));
                    cmd.Parameters.Add(new OracleParameter("m", C.GetModel()));
                    cmd.Parameters.Add(new OracleParameter("carid", C.GetCarId()));
                    cmd.ExecuteNonQuery();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        public DataTable ViewAllCars()
        {
            try
            {
                string query = "Select *from Cars";
                using (OracleConnection con = new OracleConnection(ConnectionString))
                {
                    OracleDataAdapter adp = new OracleDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    adp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK);
                DataTable dt = new DataTable();
                return dt;
            }
        }
        public List<int> CarsID()
        {
            List<int> CarID = new List<int>();
            try
            {
                string query = "SELECT CARID FROM CARS";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    conn.Open();
                    OracleCommand cmd = new OracleCommand(query, conn);
                    OracleDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        CarID.Add(Convert.ToInt32(reader["CARID"]));
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);

            }
            return CarID;
        }
        public string NAME(int id)
        {
            string name = "not found";
            try
            {
                string query = "SELECT Name FROM CARS where CARID=carid";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    conn.Open();
                    OracleCommand cmd = new OracleCommand(query, conn);
                    cmd.Parameters.Add(new OracleParameter("carid", id));
                    OracleDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        name=reader["Name"].ToString();
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);

            }
            return name;
        }
        public string NUMBERPLATE(int id)
        {
            string no_plate = "not found";
            try
            {
                string query = "SELECT NumberPlate FROM CARS where CARID=carid";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    conn.Open();
                    OracleCommand cmd = new OracleCommand(query, conn);
                    cmd.Parameters.Add(new OracleParameter("carid", id));
                    OracleDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        no_plate = reader["NumberPlate"].ToString();
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);

            }
            return no_plate;
        }
        public string COLOR(int id)
        {
            string color = "not found";
            try
            {
                string query = "SELECT Color FROM CARS where CARID=carid";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    conn.Open();
                    OracleCommand cmd = new OracleCommand(query, conn);
                    cmd.Parameters.Add(new OracleParameter("carid", id));
                    OracleDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        color = reader["Color"].ToString();
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);

            }
            return color;
        }
        public int RENTALPRICE(int id)
        {
            int price = 0;
            try
            {
                string query = "SELECT RentalPrice FROM CARS where CARID=carid";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    conn.Open();
                    OracleCommand cmd = new OracleCommand(query, conn);
                    cmd.Parameters.Add(new OracleParameter("carid", id));
                    OracleDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        price = Convert.ToInt32(reader["RentalPrice"]);
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);

            }
            return price;
        }
        public string MODEL(int id)
        {
            string model = "not found";
            try
            {
                string query = "SELECT Model FROM CARS where CARID=carid";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    conn.Open();
                    OracleCommand cmd = new OracleCommand(query, conn);
                    cmd.Parameters.Add(new OracleParameter("carid", id));
                    OracleDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        model = reader["Model"].ToString();
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);

            }
            return model;
        }
        public DataTable RentedCars()
        {

            try
            {
                string query = "SELECT car.CustomerID, c.CarId ,c.NAME ,c.NUMBERPLATE,c.COLOR,c.RENTALPRICE ,c.MODEL FROM Cars c join RENTALS car on (c.CarID=car.CarID AND car.RENTALSTATUS= 'Rented')";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    OracleDataAdapter adapter = new OracleDataAdapter(query, conn);
                    DataTable table = new DataTable();

                    adapter.Fill(table);
                    return table;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                DataTable table = new DataTable();
                return table;

            }
        }
        public DataTable AvailCars()
        {

            try
            {
                string query = "SELECT C.*FROM Cars C WHERE C.CARID NOT IN  (SELECT R.CARID  FROM Rentals R  WHERE R.RENTALSTATUS = 'Rented')";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    OracleDataAdapter adapter = new OracleDataAdapter(query, conn);
                    DataTable table = new DataTable();

                    adapter.Fill(table);
                    return table;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                DataTable table = new DataTable();
                return table;

            }
        }
        public List<int> AvailCarsID()
        {
            List<int> AvailCar = new List<int>();
            try
            {
                string query = "SELECT C.CarID FROM Cars C WHERE C.CARID NOT IN ( SELECT R.CARID FROM Rentals R  WHERE R.RENTALSTATUS = 'Rented')";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    conn.Open();
                    OracleCommand cmd = new OracleCommand(query, conn);
                    OracleDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        AvailCar.Add(Convert.ToInt32(reader["CARID"]));
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);

            }
            return AvailCar;
        }
        public List<int> RentedCarsID(int cusid)
        {
            List<int> RentCar = new List<int>();
            try
            {
                string query = "SELECT c.CarId FROM Cars c join RENTALS car on (c.CarID=car.CarID AND car.RENTALSTATUS= 'Rented')Where car.CustomerID="+cusid+"";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    conn.Open();
                    OracleCommand cmd = new OracleCommand(query, conn);
                    OracleDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        RentCar.Add(Convert.ToInt32(reader["CARID"]));
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);

            }
            return RentCar;
        }
        public DataTable SearchOnBasisOfName(string name)
        {
            try
            {
                string query = "SELECT * from CARS Where Name = '" + name + "'";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    OracleDataAdapter adapter = new OracleDataAdapter(query, conn);

                    DataTable table = new DataTable();

                    adapter.Fill(table);
                    return table;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                DataTable table = new DataTable();
                return table;

            }
        }
        public DataTable SearchOnBasisOfRentalPrice(int price)
        {
            try
            {
                string query = "SELECT * from CARS Where RENTALPRICE = " + price + "";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    OracleDataAdapter adapter = new OracleDataAdapter(query, conn);

                    DataTable table = new DataTable();

                    adapter.Fill(table);
                    return table;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                DataTable table = new DataTable();
                return table;

            }
        }
        public DataTable SearchOnBasisOfColor(string color)
        {
            try
            {
                string query = "SELECT * from CARS Where COLOR = '" + color + "'";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    OracleDataAdapter adapter = new OracleDataAdapter(query, conn);

                    DataTable table = new DataTable();

                    adapter.Fill(table);
                    return table;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                DataTable table = new DataTable();
                return table;

            }
        }
        public DataTable SearchOnBasisOfNameColor(string color,string name)
        {
            try
            {
                string query = "SELECT * from CARS Where COLOR = '" + color + "' And Name = '" + name + "'";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    OracleDataAdapter adapter = new OracleDataAdapter(query, conn);

                    DataTable table = new DataTable();

                    adapter.Fill(table);
                    return table;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                DataTable table = new DataTable();
                return table;

            }
        }
        public DataTable SearchOnBasisOfNameRPrize(string name, int price)
        {
            try
            {
                string query = "SELECT * from CARS Where RENTALPRICE = " + price + " And Name = '" + name + "'";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    OracleDataAdapter adapter = new OracleDataAdapter(query, conn);

                    DataTable table = new DataTable();

                    adapter.Fill(table);
                    return table;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                DataTable table = new DataTable();
                return table;

            }
        }
        public DataTable SearchOnBasisOfColorRPrize(string color, int price)
        {
            try
            {
                string query = "SELECT * from CARS Where RENTALPRICE = " + price + " And COLOR = '" + color + "'";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    OracleDataAdapter adapter = new OracleDataAdapter(query, conn);

                    DataTable table = new DataTable();

                    adapter.Fill(table);
                    return table;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                DataTable table = new DataTable();
                return table;

            }
        }
        public DataTable SearchOnBasisOfNameColorRprice(string color, string name,int price)
        {
            try
            {
                string query = "SELECT * from CARS Where COLOR = '" + color + "' And Name = '" + name + "' AND RENTALPRICE = '" + price + "'";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    OracleDataAdapter adapter = new OracleDataAdapter(query, conn);

                    DataTable table = new DataTable();

                    adapter.Fill(table);
                    return table;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                DataTable table = new DataTable();
                return table;

            }
        }
        public List<string> CarName()
        {
            List<string> name = new List<string>();
            try
            {
                string query = "SELECT NAME FROM CARS group by NAME";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    conn.Open();
                    OracleCommand cmd = new OracleCommand(query, conn);
                    OracleDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        name.Add(reader["NAME"].ToString());
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error13: " + ex.Message);

            }
            return name;
        }
        public List<string> CarColor()
        {
            List<string> color = new List<string>();
            try
            {
                string query = "SELECT COLOR FROM CARS group by COLOR";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    conn.Open();
                    OracleCommand cmd = new OracleCommand(query, conn);
                    OracleDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        color.Add(reader["COLOR"].ToString());
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error13: " + ex.Message);

            }
            return color;
        }
        public List<int> CarPrice()
        {
            List<int> price = new List<int>();
            try
            {
                string query = "SELECT RENTALPRICE FROM CARS group by RENTALPRICE";

                using (OracleConnection conn = new OracleConnection(ConnectionString))
                {
                    conn.Open();
                    OracleCommand cmd = new OracleCommand(query, conn);
                    OracleDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        price.Add(Convert.ToInt32(reader["RENTALPRICE"]));
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error13: " + ex.Message);

            }
            return price;
        }
    }
}

