﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Gallery
{
    public partial class CustomerLogIn : Form
    {
        int Id;

        public CustomerLogIn()
        {

            InitializeComponent();
            pass_box.UseSystemPasswordChar = true;

        }

        private void CustomerLogIn_Load(object sender, EventArgs e)
        {

        }

        private void CustomerLogIn_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            this.Hide();
            dashboard.Show();
        }

        private void login_btn_Click(object sender, EventArgs e)
        {
            Customers C = new Customers();
            CustomerData c= new CustomerData();
             c= C.SearchOInBasisOfUsernamePassword(name_box.Text.ToString(), pass_box.Text.ToString());
            int id=c.GetCustomerId();
            if (id > 0)
            {
                MessageBox.Show("Login Successful!");
                Id = id;
                CustomerDash customerDash = new CustomerDash(Id);
                this.Hide();
                customerDash.Show();
            }
            else
            {
                MessageBox.Show("Invalid Username or Passwrod !", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void create_btn_Click(object sender, EventArgs e)
        {
            CustomerSignup customerSignup = new CustomerSignup();   
            this.Hide();
            customerSignup.Show();
        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void pass_check_CheckedChanged(object sender, EventArgs e)
        {
            if (pass_check.Checked)
            {
                // Show password
                pass_box.UseSystemPasswordChar = false;
            }
            else
            {
                // Hide password
                pass_box.UseSystemPasswordChar = true;
            }
        }
    }
}
