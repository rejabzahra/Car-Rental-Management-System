﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Gallery
{
    public partial class AdminLogin : Form
    {
        
        int Id;
        public AdminLogin()
        {
            InitializeComponent();
            pass_box.UseSystemPasswordChar = true;
        }

        private void AdminLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            this.Hide();
            dashboard.Show();
        }

        private void create_btn_Click(object sender, EventArgs e)
        {
            
        }

        private void AdminLogin_Load(object sender, EventArgs e)
        {

        }
        private void login_btn_Click(object sender, EventArgs e)
        {
            Admin A=new Admin();
            AdminData a=new AdminData();
            a=A.SearchOInBasisOfUsernamePassword(name_box.Text.ToString(), pass_box.Text.ToString());
            int id=a.GetAdminId();
            if (id > 0)
            {
                MessageBox.Show("Login Successful!");
                Id = id;
                AdminDash admin = new AdminDash(Id);
                this.Hide();
                admin.Show();
            }
            else
            {
                MessageBox.Show("Invalid Username or Passwrod !","Login Failed",MessageBoxButtons.OK,MessageBoxIcon.Error);

            }

           
        }

        private void pass_check_CheckedChanged(object sender, EventArgs e)
        {
            if (pass_check.Checked)
            {
                // Show password
                pass_box.UseSystemPasswordChar = false;
            }
            else
            {
                // Hide password
                pass_box.UseSystemPasswordChar = true;
            }
        }

        private void admin_panel_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
