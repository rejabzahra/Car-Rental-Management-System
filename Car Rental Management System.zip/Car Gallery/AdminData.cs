﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Car_Gallery
{
    internal class AdminData:Person
    {
        int AdminId;
        
        public AdminData( string username, string password, string fullName, string email, string phone):base(username, password, fullName, email, phone)
        {
            AdminId = 0;
           
        }
        public AdminData():base() 
        {
            AdminId = 0;
           
        }
        public void SetAdminId(int id)
        {
            AdminId = id;
        }
        public int GetAdminId()
        {
            return AdminId;
        }
        public void SetPassword(string pass)
        {
            base.Setpassword(pass);
        }
        public string GetPassword()
        {
            return base.Getpassword();
        }
        public void SetUsername(string uname)
        {
            base.Setusername(uname);
        }
        public string GetUsername()
        {
            return base.Getusername();
        }
        public void SetEmail(string email)
        {
            base.Setemail( email);
        }
        public string GetEmail()
        {
            return base.Getemail();
        }
        public void SetFullName(string fname)
        {
            base.SetfullName(fname);
        }
        public string GetFullName()
        {
            return base.GetfullName();
        }
        public void SetPhone(string phonne)
        {
            base.Setphone(phonne);
        }
        public string GetPhone()
        {
            return base.Getphone();
        }
    }
}
