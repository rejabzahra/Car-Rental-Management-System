﻿namespace Car_Gallery
{
    partial class RentCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RentCar));
            this.rentcar_lbl = new System.Windows.Forms.Label();
            this.back_btn = new System.Windows.Forms.Button();
            this.id_cmbo = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.model_box = new System.Windows.Forms.TextBox();
            this.model_lbl = new System.Windows.Forms.Label();
            this.rentalprice_box = new System.Windows.Forms.TextBox();
            this.rentalprice_lbl = new System.Windows.Forms.Label();
            this.color_box = new System.Windows.Forms.TextBox();
            this.name_lbl = new System.Windows.Forms.Label();
            this.noplate_box = new System.Windows.Forms.TextBox();
            this.noplate_lbl = new System.Windows.Forms.Label();
            this.name_box = new System.Windows.Forms.TextBox();
            this.color_lbl = new System.Windows.Forms.Label();
            this.Rent_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rentcar_lbl
            // 
            this.rentcar_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rentcar_lbl.AutoSize = true;
            this.rentcar_lbl.BackColor = System.Drawing.Color.Transparent;
            this.rentcar_lbl.Font = new System.Drawing.Font("Impact", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rentcar_lbl.ForeColor = System.Drawing.Color.White;
            this.rentcar_lbl.Location = new System.Drawing.Point(590, 64);
            this.rentcar_lbl.Name = "rentcar_lbl";
            this.rentcar_lbl.Size = new System.Drawing.Size(502, 117);
            this.rentcar_lbl.TabIndex = 21;
            this.rentcar_lbl.Text = "*Rent A Car*";
            this.rentcar_lbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // back_btn
            // 
            this.back_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.back_btn.BackColor = System.Drawing.Color.White;
            this.back_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back_btn.Location = new System.Drawing.Point(52, 46);
            this.back_btn.Name = "back_btn";
            this.back_btn.Size = new System.Drawing.Size(115, 42);
            this.back_btn.TabIndex = 63;
            this.back_btn.Text = "Back";
            this.back_btn.UseVisualStyleBackColor = false;
            this.back_btn.Click += new System.EventHandler(this.back_btn_Click);
            // 
            // id_cmbo
            // 
            this.id_cmbo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.id_cmbo.FormattingEnabled = true;
            this.id_cmbo.Location = new System.Drawing.Point(839, 245);
            this.id_cmbo.Name = "id_cmbo";
            this.id_cmbo.Size = new System.Drawing.Size(312, 28);
            this.id_cmbo.TabIndex = 62;
            this.id_cmbo.SelectedIndexChanged += new System.EventHandler(this.id_cmbo_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(531, 245);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 36);
            this.label1.TabIndex = 61;
            this.label1.Text = "Car ID :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // model_box
            // 
            this.model_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.model_box.BackColor = System.Drawing.Color.White;
            this.model_box.Location = new System.Drawing.Point(839, 643);
            this.model_box.Multiline = true;
            this.model_box.Name = "model_box";
            this.model_box.Size = new System.Drawing.Size(312, 45);
            this.model_box.TabIndex = 60;
            this.model_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // model_lbl
            // 
            this.model_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.model_lbl.AutoSize = true;
            this.model_lbl.BackColor = System.Drawing.Color.Transparent;
            this.model_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.model_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.model_lbl.Location = new System.Drawing.Point(531, 652);
            this.model_lbl.Name = "model_lbl";
            this.model_lbl.Size = new System.Drawing.Size(122, 36);
            this.model_lbl.TabIndex = 59;
            this.model_lbl.Text = "Model :";
            this.model_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rentalprice_box
            // 
            this.rentalprice_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rentalprice_box.BackColor = System.Drawing.Color.White;
            this.rentalprice_box.Location = new System.Drawing.Point(839, 558);
            this.rentalprice_box.Multiline = true;
            this.rentalprice_box.Name = "rentalprice_box";
            this.rentalprice_box.Size = new System.Drawing.Size(312, 45);
            this.rentalprice_box.TabIndex = 58;
            this.rentalprice_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // rentalprice_lbl
            // 
            this.rentalprice_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rentalprice_lbl.AutoSize = true;
            this.rentalprice_lbl.BackColor = System.Drawing.Color.Transparent;
            this.rentalprice_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rentalprice_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.rentalprice_lbl.Location = new System.Drawing.Point(531, 567);
            this.rentalprice_lbl.Name = "rentalprice_lbl";
            this.rentalprice_lbl.Size = new System.Drawing.Size(204, 36);
            this.rentalprice_lbl.TabIndex = 57;
            this.rentalprice_lbl.Text = "Rental Price :";
            this.rentalprice_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // color_box
            // 
            this.color_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.color_box.BackColor = System.Drawing.Color.White;
            this.color_box.Location = new System.Drawing.Point(839, 480);
            this.color_box.Multiline = true;
            this.color_box.Name = "color_box";
            this.color_box.Size = new System.Drawing.Size(312, 45);
            this.color_box.TabIndex = 56;
            this.color_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // name_lbl
            // 
            this.name_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.name_lbl.AutoSize = true;
            this.name_lbl.BackColor = System.Drawing.Color.Transparent;
            this.name_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.name_lbl.Location = new System.Drawing.Point(531, 323);
            this.name_lbl.Name = "name_lbl";
            this.name_lbl.Size = new System.Drawing.Size(114, 36);
            this.name_lbl.TabIndex = 55;
            this.name_lbl.Text = "Name :";
            this.name_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // noplate_box
            // 
            this.noplate_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.noplate_box.BackColor = System.Drawing.Color.White;
            this.noplate_box.Location = new System.Drawing.Point(839, 397);
            this.noplate_box.Multiline = true;
            this.noplate_box.Name = "noplate_box";
            this.noplate_box.Size = new System.Drawing.Size(312, 45);
            this.noplate_box.TabIndex = 54;
            this.noplate_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.noplate_box.TextChanged += new System.EventHandler(this.noplate_box_TextChanged);
            // 
            // noplate_lbl
            // 
            this.noplate_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.noplate_lbl.AutoSize = true;
            this.noplate_lbl.BackColor = System.Drawing.Color.Transparent;
            this.noplate_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.noplate_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.noplate_lbl.Location = new System.Drawing.Point(531, 406);
            this.noplate_lbl.Name = "noplate_lbl";
            this.noplate_lbl.Size = new System.Drawing.Size(225, 36);
            this.noplate_lbl.TabIndex = 53;
            this.noplate_lbl.Text = "Number Plate :";
            this.noplate_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // name_box
            // 
            this.name_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.name_box.BackColor = System.Drawing.Color.White;
            this.name_box.Location = new System.Drawing.Point(839, 314);
            this.name_box.Multiline = true;
            this.name_box.Name = "name_box";
            this.name_box.Size = new System.Drawing.Size(312, 45);
            this.name_box.TabIndex = 52;
            this.name_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // color_lbl
            // 
            this.color_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.color_lbl.AutoSize = true;
            this.color_lbl.BackColor = System.Drawing.Color.Transparent;
            this.color_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.color_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.color_lbl.Location = new System.Drawing.Point(531, 489);
            this.color_lbl.Name = "color_lbl";
            this.color_lbl.Size = new System.Drawing.Size(111, 36);
            this.color_lbl.TabIndex = 51;
            this.color_lbl.Text = "Color :";
            this.color_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Rent_btn
            // 
            this.Rent_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Rent_btn.BackColor = System.Drawing.Color.White;
            this.Rent_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rent_btn.Location = new System.Drawing.Point(735, 790);
            this.Rent_btn.Name = "Rent_btn";
            this.Rent_btn.Size = new System.Drawing.Size(264, 56);
            this.Rent_btn.TabIndex = 50;
            this.Rent_btn.Text = "Rent";
            this.Rent_btn.UseVisualStyleBackColor = false;
            this.Rent_btn.Click += new System.EventHandler(this.Rent_btn_Click);
            // 
            // RentCar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1693, 890);
            this.Controls.Add(this.back_btn);
            this.Controls.Add(this.id_cmbo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.model_box);
            this.Controls.Add(this.model_lbl);
            this.Controls.Add(this.rentalprice_box);
            this.Controls.Add(this.rentalprice_lbl);
            this.Controls.Add(this.color_box);
            this.Controls.Add(this.name_lbl);
            this.Controls.Add(this.noplate_box);
            this.Controls.Add(this.noplate_lbl);
            this.Controls.Add(this.name_box);
            this.Controls.Add(this.color_lbl);
            this.Controls.Add(this.Rent_btn);
            this.Controls.Add(this.rentcar_lbl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "RentCar";
            this.Text = "RentCar";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.RentCar_FormClosing);
            this.Load += new System.EventHandler(this.RentCar_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label rentcar_lbl;
        private System.Windows.Forms.Button back_btn;
        private System.Windows.Forms.ComboBox id_cmbo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox model_box;
        private System.Windows.Forms.Label model_lbl;
        private System.Windows.Forms.TextBox rentalprice_box;
        private System.Windows.Forms.Label rentalprice_lbl;
        private System.Windows.Forms.TextBox color_box;
        private System.Windows.Forms.Label name_lbl;
        private System.Windows.Forms.TextBox noplate_box;
        private System.Windows.Forms.Label noplate_lbl;
        private System.Windows.Forms.TextBox name_box;
        private System.Windows.Forms.Label color_lbl;
        private System.Windows.Forms.Button Rent_btn;
    }
}