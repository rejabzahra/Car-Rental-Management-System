﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Gallery
{
    public partial class Rem_Upd_Car : Form
    {
        int ID;
        public Rem_Upd_Car( int iD)
        {
            InitializeComponent();
            ID = iD;
        }

        private void Rem_Upd_Car_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void search_lbl_Click(object sender, EventArgs e)
        {

        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminDash adminDash = new AdminDash(ID);
            adminDash.Show();
        }

        private void Rem_Upd_Car_Load(object sender, EventArgs e)
        {
            Car C=new Car();
            List<int> carsid = new List<int>();
            carsid = C.CarsID();
            for (int i = 0; i < carsid.Count; i++)
            {
                id_cmbo.Items.Add(carsid[i]);
            }
        }

        private void id_cmbo_SelectedIndexChanged(object sender, EventArgs e)
        {
            Car C = new Car();

            name_box.Text = C.NAME(Convert.ToInt32(id_cmbo.SelectedItem));
            noplate_box.Text = C.NUMBERPLATE(Convert.ToInt32(id_cmbo.SelectedItem));
            color_box.Text = C.COLOR(Convert.ToInt32(id_cmbo.SelectedItem));
            rentalprice_box.Text = C.RENTALPRICE(Convert.ToInt32(id_cmbo.SelectedItem)).ToString();
            model_box.Text = C.MODEL(Convert.ToInt32(id_cmbo.SelectedItem));
        }

        private void update_btn_Click(object sender, EventArgs e)
        {
            Car C = new Car();
            CarsData carsData = new CarsData(name_box.Text.ToString(), noplate_box.Text.ToString(),
                color_box.Text.ToString(), Convert.ToInt32(rentalprice_box.Text), model_box.Text.ToString());
            carsData.SetCarId(Convert.ToInt32(id_cmbo.SelectedItem));

            C.UpdateDataFromLists(carsData);
            MessageBox.Show("Car Data Updated Successfully");
            Rem_Upd_Car cars = new Rem_Upd_Car(ID);
            this.Hide();
            cars.Show();
        }

        private void delete_btn_Click(object sender, EventArgs e)
        {
            Car C = new Car();

            C.RemoveDataFromLists(Convert.ToInt32(id_cmbo.SelectedItem) );
            MessageBox.Show("Car Data Removed Successfully");
            Rem_Upd_Car car = new Rem_Upd_Car(ID);
            this.Hide();
            car.Show();
        }
    }
}
