﻿namespace Car_Gallery
{
    partial class RentingHistory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RentingHistory));
            this.back_btn = new System.Windows.Forms.Button();
            this.history_grdv = new System.Windows.Forms.DataGridView();
            this.history_lbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.history_grdv)).BeginInit();
            this.SuspendLayout();
            // 
            // back_btn
            // 
            this.back_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.back_btn.BackColor = System.Drawing.Color.White;
            this.back_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back_btn.Location = new System.Drawing.Point(61, 29);
            this.back_btn.Name = "back_btn";
            this.back_btn.Size = new System.Drawing.Size(111, 48);
            this.back_btn.TabIndex = 52;
            this.back_btn.Text = "Back";
            this.back_btn.UseVisualStyleBackColor = false;
            this.back_btn.Click += new System.EventHandler(this.back_btn_Click);
            // 
            // history_grdv
            // 
            this.history_grdv.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.history_grdv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.history_grdv.BackgroundColor = System.Drawing.Color.White;
            this.history_grdv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.history_grdv.Location = new System.Drawing.Point(61, 232);
            this.history_grdv.Name = "history_grdv";
            this.history_grdv.RowHeadersWidth = 62;
            this.history_grdv.RowTemplate.Height = 28;
            this.history_grdv.Size = new System.Drawing.Size(1810, 549);
            this.history_grdv.TabIndex = 51;
            // 
            // history_lbl
            // 
            this.history_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.history_lbl.AutoSize = true;
            this.history_lbl.BackColor = System.Drawing.Color.Transparent;
            this.history_lbl.Font = new System.Drawing.Font("Impact", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.history_lbl.ForeColor = System.Drawing.Color.White;
            this.history_lbl.Location = new System.Drawing.Point(752, -1);
            this.history_lbl.Name = "history_lbl";
            this.history_lbl.Size = new System.Drawing.Size(708, 117);
            this.history_lbl.TabIndex = 50;
            this.history_lbl.Text = "*Renting History*";
            this.history_lbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // RentingHistory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1924, 938);
            this.Controls.Add(this.back_btn);
            this.Controls.Add(this.history_grdv);
            this.Controls.Add(this.history_lbl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "RentingHistory";
            this.Text = "RentingHistory";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.RentingHistory_FormClosing);
            this.Load += new System.EventHandler(this.RentingHistory_Load);
            ((System.ComponentModel.ISupportInitialize)(this.history_grdv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button back_btn;
        private System.Windows.Forms.DataGridView history_grdv;
        private System.Windows.Forms.Label history_lbl;
    }
}