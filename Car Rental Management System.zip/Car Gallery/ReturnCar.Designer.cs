﻿namespace Car_Gallery
{
    partial class ReturnCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReturnCar));
            this.back_btn = new System.Windows.Forms.Button();
            this.id_cmbo = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.model_box = new System.Windows.Forms.TextBox();
            this.model_lbl = new System.Windows.Forms.Label();
            this.rentalprice_box = new System.Windows.Forms.TextBox();
            this.rentalprice_lbl = new System.Windows.Forms.Label();
            this.color_box = new System.Windows.Forms.TextBox();
            this.name_lbl = new System.Windows.Forms.Label();
            this.noplate_box = new System.Windows.Forms.TextBox();
            this.noplate_lbl = new System.Windows.Forms.Label();
            this.name_box = new System.Windows.Forms.TextBox();
            this.color_lbl = new System.Windows.Forms.Label();
            this.return_btn = new System.Windows.Forms.Button();
            this.returncar_lbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // back_btn
            // 
            this.back_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.back_btn.BackColor = System.Drawing.Color.White;
            this.back_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back_btn.Location = new System.Drawing.Point(40, 30);
            this.back_btn.Name = "back_btn";
            this.back_btn.Size = new System.Drawing.Size(138, 56);
            this.back_btn.TabIndex = 63;
            this.back_btn.Text = "Back";
            this.back_btn.UseVisualStyleBackColor = false;
            this.back_btn.Click += new System.EventHandler(this.back_btn_Click);
            // 
            // id_cmbo
            // 
            this.id_cmbo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.id_cmbo.FormattingEnabled = true;
            this.id_cmbo.Location = new System.Drawing.Point(902, 266);
            this.id_cmbo.Name = "id_cmbo";
            this.id_cmbo.Size = new System.Drawing.Size(312, 28);
            this.id_cmbo.TabIndex = 62;
            this.id_cmbo.SelectedIndexChanged += new System.EventHandler(this.id_cmbo_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(594, 266);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 36);
            this.label1.TabIndex = 61;
            this.label1.Text = "Car ID :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // model_box
            // 
            this.model_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.model_box.BackColor = System.Drawing.Color.White;
            this.model_box.Location = new System.Drawing.Point(902, 664);
            this.model_box.Multiline = true;
            this.model_box.Name = "model_box";
            this.model_box.Size = new System.Drawing.Size(312, 45);
            this.model_box.TabIndex = 60;
            this.model_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // model_lbl
            // 
            this.model_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.model_lbl.AutoSize = true;
            this.model_lbl.BackColor = System.Drawing.Color.Transparent;
            this.model_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.model_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.model_lbl.Location = new System.Drawing.Point(594, 673);
            this.model_lbl.Name = "model_lbl";
            this.model_lbl.Size = new System.Drawing.Size(122, 36);
            this.model_lbl.TabIndex = 59;
            this.model_lbl.Text = "Model :";
            this.model_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rentalprice_box
            // 
            this.rentalprice_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rentalprice_box.BackColor = System.Drawing.Color.White;
            this.rentalprice_box.Location = new System.Drawing.Point(902, 579);
            this.rentalprice_box.Multiline = true;
            this.rentalprice_box.Name = "rentalprice_box";
            this.rentalprice_box.Size = new System.Drawing.Size(312, 45);
            this.rentalprice_box.TabIndex = 58;
            this.rentalprice_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // rentalprice_lbl
            // 
            this.rentalprice_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rentalprice_lbl.AutoSize = true;
            this.rentalprice_lbl.BackColor = System.Drawing.Color.Transparent;
            this.rentalprice_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rentalprice_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.rentalprice_lbl.Location = new System.Drawing.Point(594, 588);
            this.rentalprice_lbl.Name = "rentalprice_lbl";
            this.rentalprice_lbl.Size = new System.Drawing.Size(204, 36);
            this.rentalprice_lbl.TabIndex = 57;
            this.rentalprice_lbl.Text = "Rental Price :";
            this.rentalprice_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // color_box
            // 
            this.color_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.color_box.BackColor = System.Drawing.Color.White;
            this.color_box.Location = new System.Drawing.Point(902, 501);
            this.color_box.Multiline = true;
            this.color_box.Name = "color_box";
            this.color_box.Size = new System.Drawing.Size(312, 45);
            this.color_box.TabIndex = 56;
            this.color_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // name_lbl
            // 
            this.name_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.name_lbl.AutoSize = true;
            this.name_lbl.BackColor = System.Drawing.Color.Transparent;
            this.name_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.name_lbl.Location = new System.Drawing.Point(594, 344);
            this.name_lbl.Name = "name_lbl";
            this.name_lbl.Size = new System.Drawing.Size(114, 36);
            this.name_lbl.TabIndex = 55;
            this.name_lbl.Text = "Name :";
            this.name_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // noplate_box
            // 
            this.noplate_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.noplate_box.BackColor = System.Drawing.Color.White;
            this.noplate_box.Location = new System.Drawing.Point(902, 418);
            this.noplate_box.Multiline = true;
            this.noplate_box.Name = "noplate_box";
            this.noplate_box.Size = new System.Drawing.Size(312, 45);
            this.noplate_box.TabIndex = 54;
            this.noplate_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // noplate_lbl
            // 
            this.noplate_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.noplate_lbl.AutoSize = true;
            this.noplate_lbl.BackColor = System.Drawing.Color.Transparent;
            this.noplate_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.noplate_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.noplate_lbl.Location = new System.Drawing.Point(594, 427);
            this.noplate_lbl.Name = "noplate_lbl";
            this.noplate_lbl.Size = new System.Drawing.Size(225, 36);
            this.noplate_lbl.TabIndex = 53;
            this.noplate_lbl.Text = "Number Plate :";
            this.noplate_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // name_box
            // 
            this.name_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.name_box.BackColor = System.Drawing.Color.White;
            this.name_box.Location = new System.Drawing.Point(902, 335);
            this.name_box.Multiline = true;
            this.name_box.Name = "name_box";
            this.name_box.Size = new System.Drawing.Size(312, 45);
            this.name_box.TabIndex = 52;
            this.name_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // color_lbl
            // 
            this.color_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.color_lbl.AutoSize = true;
            this.color_lbl.BackColor = System.Drawing.Color.Transparent;
            this.color_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.color_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.color_lbl.Location = new System.Drawing.Point(594, 510);
            this.color_lbl.Name = "color_lbl";
            this.color_lbl.Size = new System.Drawing.Size(111, 36);
            this.color_lbl.TabIndex = 51;
            this.color_lbl.Text = "Color :";
            this.color_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // return_btn
            // 
            this.return_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.return_btn.BackColor = System.Drawing.Color.White;
            this.return_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.return_btn.Location = new System.Drawing.Point(798, 811);
            this.return_btn.Name = "return_btn";
            this.return_btn.Size = new System.Drawing.Size(264, 56);
            this.return_btn.TabIndex = 50;
            this.return_btn.Text = "Return";
            this.return_btn.UseVisualStyleBackColor = false;
            this.return_btn.Click += new System.EventHandler(this.return_btn_Click);
            // 
            // returncar_lbl
            // 
            this.returncar_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.returncar_lbl.AutoSize = true;
            this.returncar_lbl.BackColor = System.Drawing.Color.Transparent;
            this.returncar_lbl.Font = new System.Drawing.Font("Impact", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.returncar_lbl.ForeColor = System.Drawing.Color.White;
            this.returncar_lbl.Location = new System.Drawing.Point(618, 30);
            this.returncar_lbl.Name = "returncar_lbl";
            this.returncar_lbl.Size = new System.Drawing.Size(586, 117);
            this.returncar_lbl.TabIndex = 64;
            this.returncar_lbl.Text = "*Return A Car*";
            this.returncar_lbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // ReturnCar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1684, 961);
            this.Controls.Add(this.returncar_lbl);
            this.Controls.Add(this.back_btn);
            this.Controls.Add(this.id_cmbo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.model_box);
            this.Controls.Add(this.model_lbl);
            this.Controls.Add(this.rentalprice_box);
            this.Controls.Add(this.rentalprice_lbl);
            this.Controls.Add(this.color_box);
            this.Controls.Add(this.name_lbl);
            this.Controls.Add(this.noplate_box);
            this.Controls.Add(this.noplate_lbl);
            this.Controls.Add(this.name_box);
            this.Controls.Add(this.color_lbl);
            this.Controls.Add(this.return_btn);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ReturnCar";
            this.Text = "v";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ReturnCar_FormClosing);
            this.Load += new System.EventHandler(this.ReturnCar_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button back_btn;
        private System.Windows.Forms.ComboBox id_cmbo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox model_box;
        private System.Windows.Forms.Label model_lbl;
        private System.Windows.Forms.TextBox rentalprice_box;
        private System.Windows.Forms.Label rentalprice_lbl;
        private System.Windows.Forms.TextBox color_box;
        private System.Windows.Forms.Label name_lbl;
        private System.Windows.Forms.TextBox noplate_box;
        private System.Windows.Forms.Label noplate_lbl;
        private System.Windows.Forms.TextBox name_box;
        private System.Windows.Forms.Label color_lbl;
        private System.Windows.Forms.Button return_btn;
        private System.Windows.Forms.Label returncar_lbl;
    }
}