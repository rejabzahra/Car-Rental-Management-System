﻿namespace Car_Gallery
{
    partial class ViewCars
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewCars));
            this.viewcars_lbl = new System.Windows.Forms.Label();
            this.cars_grdv = new System.Windows.Forms.DataGridView();
            this.back_btn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.cars_grdv)).BeginInit();
            this.SuspendLayout();
            // 
            // viewcars_lbl
            // 
            this.viewcars_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.viewcars_lbl.AutoSize = true;
            this.viewcars_lbl.BackColor = System.Drawing.Color.Transparent;
            this.viewcars_lbl.Font = new System.Drawing.Font("Impact", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewcars_lbl.ForeColor = System.Drawing.Color.White;
            this.viewcars_lbl.Location = new System.Drawing.Point(713, 43);
            this.viewcars_lbl.Name = "viewcars_lbl";
            this.viewcars_lbl.Size = new System.Drawing.Size(608, 117);
            this.viewcars_lbl.TabIndex = 24;
            this.viewcars_lbl.Text = "*View All Cars*";
            this.viewcars_lbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // cars_grdv
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cars_grdv.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.cars_grdv.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cars_grdv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.cars_grdv.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Constantia", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.cars_grdv.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.cars_grdv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.cars_grdv.DefaultCellStyle = dataGridViewCellStyle3;
            this.cars_grdv.Location = new System.Drawing.Point(50, 245);
            this.cars_grdv.Name = "cars_grdv";
            this.cars_grdv.RowHeadersWidth = 62;
            this.cars_grdv.RowTemplate.Height = 28;
            this.cars_grdv.Size = new System.Drawing.Size(1823, 756);
            this.cars_grdv.TabIndex = 45;
            this.cars_grdv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.cars_grdv_CellContentClick);
            // 
            // back_btn
            // 
            this.back_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.back_btn.BackColor = System.Drawing.Color.White;
            this.back_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back_btn.Location = new System.Drawing.Point(50, 32);
            this.back_btn.Name = "back_btn";
            this.back_btn.Size = new System.Drawing.Size(140, 50);
            this.back_btn.TabIndex = 49;
            this.back_btn.Text = "Back";
            this.back_btn.UseVisualStyleBackColor = false;
            this.back_btn.Click += new System.EventHandler(this.back_btn_Click);
            // 
            // ViewCars
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1924, 1035);
            this.Controls.Add(this.back_btn);
            this.Controls.Add(this.cars_grdv);
            this.Controls.Add(this.viewcars_lbl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ViewCars";
            this.Text = "ViewCars";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ViewCars_FormClosing);
            this.Load += new System.EventHandler(this.ViewCars_Load);
            ((System.ComponentModel.ISupportInitialize)(this.cars_grdv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label viewcars_lbl;
        private System.Windows.Forms.DataGridView cars_grdv;
        private System.Windows.Forms.Button back_btn;
    }
}