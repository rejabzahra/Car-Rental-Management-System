﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Gallery
{
    internal class Person
    {
        string Username;
        string Password;
        string FullName;
        string Email;
        string Phone;
        public Person(string username, string password, string fullName, string email, string phone)
        {
            Username = username;
            Password = password;
            FullName = fullName;
            Email = email;
            Phone = phone;
        }
        public Person()
        {
            Username = "";
            Password = "";
            FullName = "";
            Email = "";
            Phone = "";
        }

        public void Setpassword(string pass)
        {
            Password = pass;
        }
        public string Getpassword()
        {
            return Password;
        }
        public void Setusername(string uname)
        {
            Username = uname;
        }
        public string Getusername()
        {
            return Username;
        }
        public void Setemail(string email)
        {
            Email = email;
        }
        public string Getemail()
        {
            return Email;
        }
        public void SetfullName(string fname)
        {
            FullName = fname;
        }
        public string GetfullName()
        {
            return FullName;
        }
        public void Setphone(string phonne)
        {
            Phone = phonne;
        }
        public string Getphone()
        {
            return Phone;
        }
    }
}
