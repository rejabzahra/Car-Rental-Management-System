﻿namespace Car_Gallery
{
    partial class Rem_Upd_Car
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Rem_Upd_Car));
            this.search_lbl = new System.Windows.Forms.Label();
            this.model_box = new System.Windows.Forms.TextBox();
            this.model_lbl = new System.Windows.Forms.Label();
            this.rentalprice_box = new System.Windows.Forms.TextBox();
            this.rentalprice_lbl = new System.Windows.Forms.Label();
            this.color_box = new System.Windows.Forms.TextBox();
            this.name_lbl = new System.Windows.Forms.Label();
            this.noplate_box = new System.Windows.Forms.TextBox();
            this.noplate_lbl = new System.Windows.Forms.Label();
            this.name_box = new System.Windows.Forms.TextBox();
            this.color_lbl = new System.Windows.Forms.Label();
            this.update_btn = new System.Windows.Forms.Button();
            this.id_cmbo = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.delete_btn = new System.Windows.Forms.Button();
            this.back_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // search_lbl
            // 
            this.search_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.search_lbl.AutoSize = true;
            this.search_lbl.BackColor = System.Drawing.Color.Transparent;
            this.search_lbl.Font = new System.Drawing.Font("Impact", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search_lbl.ForeColor = System.Drawing.Color.White;
            this.search_lbl.Location = new System.Drawing.Point(470, 47);
            this.search_lbl.Name = "search_lbl";
            this.search_lbl.Size = new System.Drawing.Size(862, 117);
            this.search_lbl.TabIndex = 24;
            this.search_lbl.Text = "*Update / Delete Car*";
            this.search_lbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.search_lbl.Click += new System.EventHandler(this.search_lbl_Click);
            // 
            // model_box
            // 
            this.model_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.model_box.BackColor = System.Drawing.Color.White;
            this.model_box.Location = new System.Drawing.Point(932, 609);
            this.model_box.Multiline = true;
            this.model_box.Name = "model_box";
            this.model_box.Size = new System.Drawing.Size(312, 45);
            this.model_box.TabIndex = 44;
            this.model_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // model_lbl
            // 
            this.model_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.model_lbl.AutoSize = true;
            this.model_lbl.BackColor = System.Drawing.Color.Transparent;
            this.model_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.model_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.model_lbl.Location = new System.Drawing.Point(624, 618);
            this.model_lbl.Name = "model_lbl";
            this.model_lbl.Size = new System.Drawing.Size(122, 36);
            this.model_lbl.TabIndex = 43;
            this.model_lbl.Text = "Model :";
            this.model_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rentalprice_box
            // 
            this.rentalprice_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rentalprice_box.BackColor = System.Drawing.Color.White;
            this.rentalprice_box.Location = new System.Drawing.Point(932, 524);
            this.rentalprice_box.Multiline = true;
            this.rentalprice_box.Name = "rentalprice_box";
            this.rentalprice_box.Size = new System.Drawing.Size(312, 45);
            this.rentalprice_box.TabIndex = 42;
            this.rentalprice_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // rentalprice_lbl
            // 
            this.rentalprice_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rentalprice_lbl.AutoSize = true;
            this.rentalprice_lbl.BackColor = System.Drawing.Color.Transparent;
            this.rentalprice_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rentalprice_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.rentalprice_lbl.Location = new System.Drawing.Point(624, 533);
            this.rentalprice_lbl.Name = "rentalprice_lbl";
            this.rentalprice_lbl.Size = new System.Drawing.Size(204, 36);
            this.rentalprice_lbl.TabIndex = 41;
            this.rentalprice_lbl.Text = "Rental Price :";
            this.rentalprice_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // color_box
            // 
            this.color_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.color_box.BackColor = System.Drawing.Color.White;
            this.color_box.Location = new System.Drawing.Point(932, 446);
            this.color_box.Multiline = true;
            this.color_box.Name = "color_box";
            this.color_box.Size = new System.Drawing.Size(312, 45);
            this.color_box.TabIndex = 40;
            this.color_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // name_lbl
            // 
            this.name_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.name_lbl.AutoSize = true;
            this.name_lbl.BackColor = System.Drawing.Color.Transparent;
            this.name_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.name_lbl.Location = new System.Drawing.Point(624, 289);
            this.name_lbl.Name = "name_lbl";
            this.name_lbl.Size = new System.Drawing.Size(114, 36);
            this.name_lbl.TabIndex = 39;
            this.name_lbl.Text = "Name :";
            this.name_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // noplate_box
            // 
            this.noplate_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.noplate_box.BackColor = System.Drawing.Color.White;
            this.noplate_box.Location = new System.Drawing.Point(932, 363);
            this.noplate_box.Multiline = true;
            this.noplate_box.Name = "noplate_box";
            this.noplate_box.Size = new System.Drawing.Size(312, 45);
            this.noplate_box.TabIndex = 38;
            this.noplate_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // noplate_lbl
            // 
            this.noplate_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.noplate_lbl.AutoSize = true;
            this.noplate_lbl.BackColor = System.Drawing.Color.Transparent;
            this.noplate_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.noplate_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.noplate_lbl.Location = new System.Drawing.Point(624, 372);
            this.noplate_lbl.Name = "noplate_lbl";
            this.noplate_lbl.Size = new System.Drawing.Size(225, 36);
            this.noplate_lbl.TabIndex = 37;
            this.noplate_lbl.Text = "Number Plate :";
            this.noplate_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // name_box
            // 
            this.name_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.name_box.BackColor = System.Drawing.Color.White;
            this.name_box.Location = new System.Drawing.Point(932, 280);
            this.name_box.Multiline = true;
            this.name_box.Name = "name_box";
            this.name_box.Size = new System.Drawing.Size(312, 45);
            this.name_box.TabIndex = 36;
            this.name_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // color_lbl
            // 
            this.color_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.color_lbl.AutoSize = true;
            this.color_lbl.BackColor = System.Drawing.Color.Transparent;
            this.color_lbl.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.color_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.color_lbl.Location = new System.Drawing.Point(624, 455);
            this.color_lbl.Name = "color_lbl";
            this.color_lbl.Size = new System.Drawing.Size(111, 36);
            this.color_lbl.TabIndex = 35;
            this.color_lbl.Text = "Color :";
            this.color_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // update_btn
            // 
            this.update_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.update_btn.BackColor = System.Drawing.Color.White;
            this.update_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.update_btn.Location = new System.Drawing.Point(828, 756);
            this.update_btn.Name = "update_btn";
            this.update_btn.Size = new System.Drawing.Size(264, 56);
            this.update_btn.TabIndex = 34;
            this.update_btn.Text = "UPDATE";
            this.update_btn.UseVisualStyleBackColor = false;
            this.update_btn.Click += new System.EventHandler(this.update_btn_Click);
            // 
            // id_cmbo
            // 
            this.id_cmbo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.id_cmbo.FormattingEnabled = true;
            this.id_cmbo.Location = new System.Drawing.Point(932, 211);
            this.id_cmbo.Name = "id_cmbo";
            this.id_cmbo.Size = new System.Drawing.Size(312, 28);
            this.id_cmbo.TabIndex = 46;
            this.id_cmbo.SelectedIndexChanged += new System.EventHandler(this.id_cmbo_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(624, 211);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 36);
            this.label1.TabIndex = 45;
            this.label1.Text = "Car ID :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // delete_btn
            // 
            this.delete_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.delete_btn.BackColor = System.Drawing.Color.White;
            this.delete_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delete_btn.Location = new System.Drawing.Point(828, 843);
            this.delete_btn.Name = "delete_btn";
            this.delete_btn.Size = new System.Drawing.Size(264, 56);
            this.delete_btn.TabIndex = 47;
            this.delete_btn.Text = "DELETE";
            this.delete_btn.UseVisualStyleBackColor = false;
            this.delete_btn.Click += new System.EventHandler(this.delete_btn_Click);
            // 
            // back_btn
            // 
            this.back_btn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.back_btn.BackColor = System.Drawing.Color.White;
            this.back_btn.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back_btn.Location = new System.Drawing.Point(42, 35);
            this.back_btn.Name = "back_btn";
            this.back_btn.Size = new System.Drawing.Size(116, 48);
            this.back_btn.TabIndex = 49;
            this.back_btn.Text = "Back";
            this.back_btn.UseVisualStyleBackColor = false;
            this.back_btn.Click += new System.EventHandler(this.back_btn_Click);
            // 
            // Rem_Upd_Car
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1689, 954);
            this.Controls.Add(this.back_btn);
            this.Controls.Add(this.delete_btn);
            this.Controls.Add(this.id_cmbo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.model_box);
            this.Controls.Add(this.model_lbl);
            this.Controls.Add(this.rentalprice_box);
            this.Controls.Add(this.rentalprice_lbl);
            this.Controls.Add(this.color_box);
            this.Controls.Add(this.name_lbl);
            this.Controls.Add(this.noplate_box);
            this.Controls.Add(this.noplate_lbl);
            this.Controls.Add(this.name_box);
            this.Controls.Add(this.color_lbl);
            this.Controls.Add(this.update_btn);
            this.Controls.Add(this.search_lbl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Rem_Upd_Car";
            this.Text = "Rem_Upd_Car";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Rem_Upd_Car_FormClosing);
            this.Load += new System.EventHandler(this.Rem_Upd_Car_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label search_lbl;
        private System.Windows.Forms.TextBox model_box;
        private System.Windows.Forms.Label model_lbl;
        private System.Windows.Forms.TextBox rentalprice_box;
        private System.Windows.Forms.Label rentalprice_lbl;
        private System.Windows.Forms.TextBox color_box;
        private System.Windows.Forms.Label name_lbl;
        private System.Windows.Forms.TextBox noplate_box;
        private System.Windows.Forms.Label noplate_lbl;
        private System.Windows.Forms.TextBox name_box;
        private System.Windows.Forms.Label color_lbl;
        private System.Windows.Forms.Button update_btn;
        private System.Windows.Forms.ComboBox id_cmbo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button delete_btn;
        private System.Windows.Forms.Button back_btn;
    }
}